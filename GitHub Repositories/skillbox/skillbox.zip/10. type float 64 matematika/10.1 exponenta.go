package main

import (
	"fmt"
	"math"
)

func main() {
	var x float64
	var n int
	var e, e1 float64 = 1, 0
	var fac int = 1
	fmt.Println("эта программа вычисляет экспоненту x c заданной точностью n")
	fmt.Println("Введите x")
	fmt.Scan(&x)
	fmt.Print("введите точность знаков после запятой: ")
	fmt.Scan(&n)
	i := 1
	epsilon := 1 / math.Pow10(n)

	//for i := 2; i <= n; i++ {
	for {
		if math.Abs(e-e1) < epsilon {
			break
		}
		e1 = e
		e += (math.Pow(float64(x), float64(i)) / float64(fac))
		i++
		fac *= i

	}

	fmt.Println(e)
}

//	e2 = float64(1) + float64(x) + e1

//fmt.Println(math.Exp(x))
