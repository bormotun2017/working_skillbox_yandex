package main

import (
	"fmt"
	"math"
)

func main() {

	fmt.Println("Введите число x:")
	var x int
	fmt.Scan(&x)
	var result float64 = 1
	for i := 1; i <= x; i++ {
		result = result * math.E
	}
	fmt.Println("ответ =", result)

}
