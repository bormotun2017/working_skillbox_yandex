package main

import (
	"fmt"
	"strings"
)

func main() {
	//Напишите программу, которая выведет количество слов,
	//начинающихся с большой буквы в строке:
	//Go is an Open source programming Language that makes it Easy to build simple, reliable, and efficient Software.
	s := "Go is an Open source programming Language that makes it Easy to build simple, reliable, and efficient Software."
	count := 0
	s1 := strings.ToLower(s)
	for i := 0; i < len(s); i++ {
		if s[i] != s1[i] {
			count++
		}
	}

	fmt.Println(count)
	fmt.Println(s)
}
