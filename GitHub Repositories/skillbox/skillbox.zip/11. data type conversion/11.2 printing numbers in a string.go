package main

import (
	"fmt"
	"strconv"
	"strings"
)

func main() {
	//Напишите программу, которая выведет все части строки
	//
	//a10 10 20b 20 30c30 30 dd,
	//
	//которые можно привести к числу в десятичном формате.
	var s string
	//	var a int
	s = "a10 10 20b 20 30c30 30 dd"

	for strings.Contains(s, " ") {
		spaceIndex := strings.Index(s, " ")
		s1 := s[:spaceIndex]

		i, err := strconv.Atoi(s1)
		if err == nil {
			fmt.Print(i, " ")
			//return
		}
		//fmt.Println(i)
		s = s[spaceIndex+1:]
		s = strings.Trim(s, " ")

	}
	//i, err := strconv.Atoi(s)
	//if err == nil {
	//	fmt.Printf("%v", i)
}
