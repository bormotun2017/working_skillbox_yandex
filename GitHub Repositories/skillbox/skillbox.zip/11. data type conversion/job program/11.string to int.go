package main

import (
	"fmt"
	"strconv"
)

func main() {
	var a string
	fmt.Scan(&a)
	i, err := strconv.ParseInt(a, 10, 0)
	if err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println(i)

}
