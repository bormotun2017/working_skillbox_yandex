package main

import (
	"fmt"
	"strings"
)

func main() {
	s1 := "hello"
	s2 := "ll"
	if strings.Contains(s1, s2) {
		fmt.Println("s2 является частью s1")
	} else {
		fmt.Println("s2 не является частью s1")
	}
}
