package main

import (
	"fmt"
	"strings"
)

func main() {
	s := " !Hello World ! "
	s1 := strings.Trim(s, "! ")
	fmt.Println(s1)

}
