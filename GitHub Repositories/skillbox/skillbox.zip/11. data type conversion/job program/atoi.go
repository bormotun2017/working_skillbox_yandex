package main

import (
	"fmt"
	"strconv"
)

func main() {
	a := ""
	i, err := strconv.Atoi(a)
	if err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println(i)

}
