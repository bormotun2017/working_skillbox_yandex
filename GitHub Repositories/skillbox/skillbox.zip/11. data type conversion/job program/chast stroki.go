package main

import "fmt"

func main() {
	s := "Hello! World"
	s = s[:5] + s[6:]
	fmt.Println(s)

}
