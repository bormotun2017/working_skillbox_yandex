package main

import (
	"fmt"
	"strings"
)

func main() {
	s1 := "hello"
	s2 := "o"
	if strings.Index(s1, s2) >= 0 {
		fmt.Println("s2 является частью s1")
	} else {
		fmt.Println("s2 не является частью s1")
	}
	fmt.Println(strings.Index(s1, s2))
}
