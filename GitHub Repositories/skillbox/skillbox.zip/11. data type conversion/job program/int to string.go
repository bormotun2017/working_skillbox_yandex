package main

import (
	"fmt"
	"strconv"
)

func main() {
	var i int64
	fmt.Scan(&i)
	a := strconv.FormatInt(i, 2)
	fmt.Println(a)
}
