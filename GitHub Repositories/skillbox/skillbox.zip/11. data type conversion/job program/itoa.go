package main

import (
	"fmt"
	"strconv"
)

func main() {
	var a string
	var i int
	i = 10
	a = strconv.Itoa(i)
	fmt.Println(a)

}
