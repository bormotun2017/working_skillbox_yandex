package main

import (
	"fmt"
	"strings"
)

func main() {
	fmt.Println("Эта программа считает сколько раз буква 'а' входит в строку s")
	s := "Golang is programming language"
	a1 := len(s)
	s = strings.ReplaceAll(s, "a", "")
	a := a1 - len(s)
	fmt.Printf("буква a встречается в строке s %v раза", a)

}
