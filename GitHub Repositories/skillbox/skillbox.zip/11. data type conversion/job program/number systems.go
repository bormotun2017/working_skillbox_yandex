package main

import (
	"fmt"
	"strconv"
)

func main() {
	fmt.Println("эта программа переводит введенную строку в указанную систему счисления")
	var system int
	var number string
	fmt.Println("Введите число")
	fmt.Scan(&number)
	fmt.Println("Введите систему счисления")
	fmt.Scan(&system)
	switch system {
	case 2:
		i, err := strconv.ParseInt(number, 2, 0)
		fmt.Println(i)
		if err != nil {
			fmt.Println(err)
			return
		}
	case 10:
		i, err := strconv.ParseInt(number, 10, 0)
		fmt.Println(i)
		if err != nil {
			fmt.Println(err)
			return
		}
	case 16:
		i, err := strconv.ParseInt(number, 16, 0)
		fmt.Println(i)

		if err != nil {
			fmt.Println(err)
			return
		}
	case 32:
		i, err := strconv.ParseInt(number, 32, 0)
		fmt.Println(i)

		if err != nil {
			fmt.Println(err)
			return
		}
	}

}
