package main

import (
	"fmt"
	"strings"
)

func main() {
	s := "hello world"
	s = strings.ReplaceAll(s, "hello", "good day")
	fmt.Println(s)

}
