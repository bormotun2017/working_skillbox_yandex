package main

import (
	"fmt"
	"strings"
)

func main() {
	s1 := "hello"
	s2 := "bye"
	if strings.Compare(s1, s2) == 0 {
		fmt.Println("строки равны")

	} else if strings.Compare(s1, s2) > 0 {
		fmt.Println("Первая строка больше второй")

	} else {
		fmt.Println("Вторая строка больше первой")
	}

}
