package main

import (
	"fmt"
	"strings"
)

func main() {
	s := "hello  world "
	s = strings.Trim(s, " ")
	for strings.Contains(s, " ") {
		spaseIndex := strings.Index(s, " ")
		fmt.Println(s[:spaseIndex])
		s = s[spaseIndex+1:]
		s = strings.Trim(s, " ")
	}
	fmt.Println(s)

}
