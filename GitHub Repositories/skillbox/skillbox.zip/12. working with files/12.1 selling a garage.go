package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"time"
)

func main() {
	//Напишите программу, которая на вход получала бы строку, введённую пользователем, а в файл писала № строки, дату и сообщение в формате:
	//
	//2020-02-10 15:00:00 продам гараж.
	//
	//При вводе слова exit программа завершает работу.
	fileName := "garage.txt"
	file, err := os.Create(fileName) // создание файла
	if err != nil {                  // обработка ошибки
		fmt.Println("Не смогли создать файл", err)
		return
	}

	defer file.Close() // отложенное закрытие файла

	var text string
	var i int
	b := bufio.NewWriter(file) // буфер байт

	i = 0
	for {
		i++
		fmt.Println("Введите текст")
		fmt.Scan(&text)
		if text == "exit" {
			fmt.Println("закрытие программы")
			return
		} else {
			dt := time.Now().Format("2006-02-10 15:00:00")                            // переменная с текущей датой в заданном формате
			b.WriteString("номер строки " + strconv.Itoa(i) + "; " + dt + " " + text) // пишем в буфер данные
			b.Flush()                                                                 // записываем в файл
			b.WriteString("\n")
		}

	}

}
