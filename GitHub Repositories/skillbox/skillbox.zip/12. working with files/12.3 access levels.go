package main

import (
	"fmt"
	"log"
	"os"
)

func main() {
	//Задание 3. Уровни доступа
	//Что нужно сделать
	//Напишите программу, создающую текстовый файл только для чтения,
	//и проверьте, что в него нельзя записать данные.
	//Рекомендация
	//Для проверки создайте файл, установите режим только для чтения,
	//закройте его, а затем, открыв, попытайтесь прочесть из него данные.
	fileName := "acessLevels.txt"
	b := make([]byte, 256)        // создаем переменную на 256 байт
	for i := 0; i < len(b); i++ { // цикл для заполнения переменной
		b[i] = '1'
	}
	_, err := os.Stat(fileName)
	if os.IsNotExist(err) { //если файл не существует то создаем его только для чтения

		err := os.WriteFile(fileName, b, 0666) // создаем и записываем переменную файл и ограничиваем доступ
		if err != nil {
			panic(err)
			return
		}
		if err := os.Chmod(fileName, 0444); err != nil { // делаем файл только для чтения
			log.Fatal(err)
			return
		}

	}
	f, err := os.Open(fileName) // открытие файла
	if err != nil {             // проверка на ошибку
		fmt.Println("Ошибка открытия файла")
		return
	}
	defer f.Close()
	buf := make([]byte, 256) // создаем переменную на 256 байт

	for i := 0; i < len(b); i++ { // цикл для заполнения переменной
		buf[i] = '0'
	}
	err = os.WriteFile(fileName, buf, 0666) // пытаемся записать переменную в наш файл
	if err != nil {
		fmt.Println("Не смогли записать в файл", err)
		return
	}
	fmt.Println(string(buf)) // выводим буфер
}
