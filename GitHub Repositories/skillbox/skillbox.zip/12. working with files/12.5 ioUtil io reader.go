package main

import (
	"fmt"
	"io/ioutil"
	"os"
)

// Напишите программу, которая читает и выводит в консоль строки из файла,
// созданного в предыдущей практике, без использования ioutil.
// Если файл отсутствует или пуст, выведите в консоль соответствующее сообщение.
func main() {
	fileName := "garage.txt"
	info, err := os.Stat(fileName) // получаем информацию о файле
	if err != nil {

		if os.IsNotExist(err) { //проверка на существование файла
			fmt.Println("файл не существует")
		}
	}
	if info.Size() == 0 { //проверка размера файла
		fmt.Println("файл пустой")
	}
	file, err := os.Open(fileName) // открываем файл
	if err != nil {
		fmt.Println("err")
	}
	defer file.Close() // отложенное закрытие файла

	resultBytes, err := ioutil.ReadFile(fileName) // используем ioutil, переменная resultBytes наш буфер
	if err != nil {
		panic(err)
	}
	fmt.Printf("%s \n", resultBytes) // выводим буфер

}
