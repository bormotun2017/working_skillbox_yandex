package main

import (
	"bufio"
	"fmt"
	"log"
	"os"
)

func main() {
	f, err := os.Open("log.txt") // открытие файла
	if err != nil {              // проверка на ошибку
		fmt.Println("Ошибка открытия файла", err)
		return

	}
	scanner := bufio.NewScanner(f)
	for scanner.Scan() { //читаем построчно файл
		fmt.Println(scanner.Text())
	}

	if err := scanner.Err(); err != nil {
		log.Fatal(err)
	}

	defer f.Close() // закрытие файла после завершения программы
}
