package main

import (
	"fmt"
	"os"
)

func main() {
	f, err := os.Open("log.txt") // открытие файла
	if err != nil {              // проверка на ошибку
		fmt.Println("Ошибка открытия файла", err)
		return

	}
	//	defer f.Close()                                // закрытие файла после завершения программы
	//	buf := make([]byte, 120)                       // создали слайс на n символов
	//	if _, err := io.ReadFull(f, buf); err != nil { // чтение файла и проверка на ошибку
	//		fmt.Println("Не смогли прочитать последовательность байтов из файла", err)
	//		return
	//	}
	//	fmt.Printf("%s,\n", buf) // вывод слайса
	buf := make([]byte, 150)
	_, err = f.Read(buf)
	if err != nil {
		fmt.Println("Не смогли прочитать последовательность байтов из файла", err)
		return
	}
	fmt.Println(string(buf))
}
