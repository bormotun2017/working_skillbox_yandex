package main

import (
	"bufio"
	"fmt"
	"os"
)

func main() {
	file, err := os.Create("some.txt")
	if err := os.Chmod("some.txt", 0444); err != nil { // указали, что фал только для чтения
		fmt.Println(err) //0 всегда 0, 4 для пользователяб 4 для групп 4 для всех остальных
	}
	writer := bufio.NewWriter(file)
	if err != nil {
		fmt.Println(err)
		return
	}
	defer file.Close()

	writer.WriteString("Say hi") // запись в буфер
	writer.WriteString("\n")
	writer.WriteRune('a')
	writer.WriteString("\n")
	writer.WriteByte(67) //C
	writer.WriteString("\n")
	writer.Write([]byte{65, 66, 67}) //ABC
	writer.WriteString("\n")
	writer.Flush() // запись из буфера в файл

}
