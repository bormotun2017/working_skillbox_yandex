package main

import (
	"fmt"
	"io"
	"math/rand"
	"os"
	"time"
)

func main() {
	file, err := os.Create("log.txt")
	if err != nil {
		fmt.Println("Не смогли создать файл", err)
		return
	}
	defer file.Close()
	rand.Seed(time.Now().UnixNano())
	n := rand.Intn(101)
	fmt.Println("Введите число от 1 до 100")
	file.WriteString("Введите число от 1 до 100 \n")
	for {
		var answer int
		for {
			_, _ = fmt.Scan(&answer)                                     // цикл проверки ввода
			file.WriteString(fmt.Sprintf("Введено число %d \n", answer)) // записали в файл введенное число
			if answer < 1 || answer > 100 {                              // если число не в диапазоне 1..100
				fmt.Println("Число должно быть в диапазоне от 1 до 100")
				file.WriteString("Число должно быть в диапазоне от 1 до 100 \n")

			} else {
				break
			}
		}
		// основной цикл поиска числа
		if answer == n {
			fmt.Println("Ура число угадано")
			file.WriteString("Ура число угадано \n")
			break
		} else if answer < n {
			fmt.Println("Загаданное число больше")
			file.WriteString("Загаданное число больше \n")
		} else {
			fmt.Println("Загаданное число меньше")
			file.WriteString("Загаданное число меньше \n")

		}
	}
	f, err := os.Open("log.txt") // открыли log.txt
	if err != nil {              // обработка ошибки
		panic(err)
	}
	defer f.Close()
	buf := make([]byte, 256)                       // создали буфер на 256 байт
	if _, err := io.ReadFull(f, buf); err != nil { // читаем файл в буфер
		panic(err)
	}
	fmt.Println("====================")
	fmt.Printf("%s \n", buf) // выводим буфер
}
