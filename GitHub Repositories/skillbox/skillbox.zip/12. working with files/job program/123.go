package main

import (
	"bufio"
	"bytes"
	"fmt"
	"io/ioutil"
	"os"
	"strings"
	"time"
)

func main() {
	fmt.Println("Задание 1. Работа с файлами. С пакетом ioutil")
	var b bytes.Buffer
	fmt.Println("Введите любое сообщение:")
	fileName := "Work with files.txt"
	file, err := os.Create(fileName)
	if err != nil {
		panic(err)
	}
	defer file.Close()
	for {

		inputReader := bufio.NewReader(os.Stdin)
		//stroke, _ := inputReader.ReadString('\n')
		
		//stroke = strings.Trim(stroke, "\n")

		if strings.ToLower(stroke) == "exit" {

			break
		}
		b.WriteString(fmt.Sprintf("%s %s \n", time.Now().Format("2006-01-02 15:04:05"), stroke))

		if err := ioutil.WriteFile(fileName, b.Bytes(), 0666); err != nil {
			fmt.Println("Не смогли создать файл!", err)

		}
	}

}
