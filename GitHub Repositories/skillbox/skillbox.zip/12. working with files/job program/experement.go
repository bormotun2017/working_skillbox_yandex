package main

import (
	"bytes"
	"fmt"
	"os"
)

func main() {
	var user, password string
	file, err := os.Create("fileexperement.txt") //создаем файл
	if err != nil {
		fmt.Println("не удалось создать файл", err)
	}
	defer file.Close()
	fmt.Println("введите пользователя")
	fmt.Scan(&user)
	fmt.Println("введите пароль")
	fmt.Scan(&password)
	file.Write([]byte("пользователь " + user + "\n")) //пишем в файл напрямую
	file.Write([]byte("пароль " + password + "\n"))

	var b bytes.Buffer
	b.WriteString("пользователь " + user + "\n") //пишем в файл через левый буфер байтов
	b.WriteString("пароль " + password + "\n")

	_, err = file.Write(b.Bytes())
	if err != nil {
		fmt.Println(err)
		return
	}

}
