package main

import "fmt"

func f1(a int) { //первая функция
	fmt.Println(a)
}
func f2(b int) { // вторая функция
	fmt.Println(b)
}
func conclude(first func(int), second func(int), a, b int) { // аргументы функции не переменные а функции
	second(b) //вызываем функции в обратном порядке
	first(a)
}

func main() {
	conclude(f1, f2, 10, 20)
}
