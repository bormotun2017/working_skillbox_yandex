package main

import (
	"fmt"
)

func makeItZero(x int) { // функция обнуления
	x = 0
}
func makeItZeroPointer(x *int) { // функция обнуления; * указатель
	*x = 0 // указатель
}
func pncrement(x *int) { // функция прибавления на 1
	*x++
}
func main() {
	a := 10
	makeItZero(a) // не работает с переменной а
	fmt.Println(a)
	makeItZeroPointer(&a) // &a работает с глобальной переменной через указатель
	fmt.Println(a)
	b := 10
	c := &b        // ссылается на переменную b через указатель
	pncrement(c)   // работаем с переменной b
	fmt.Println(b) // выводим b
	fmt.Println(c) // выводит адрес в памяти переменной б. с= адрес в памяти b

}
