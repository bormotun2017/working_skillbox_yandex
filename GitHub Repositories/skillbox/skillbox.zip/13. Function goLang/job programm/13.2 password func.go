package main

import (
	"fmt"
)

func division(a, b int) {
	if b == 0 {
		fmt.Println("unkown result")
	} else {
		fmt.Println(a / b)

	}
}
func notDebug(s string) {
	if s == "debug" {
		fmt.Println("not debug")

	} else {
		fmt.Println(s)
	}
}
func chekPaswword(password string) {
	if len(password) < 6 {
		fmt.Println("password not succes")
	} else {
		fmt.Println("success")
	}
}
func printPointer(a *int) {
	if a != nil { // проверка на пустой указатель
		fmt.Println(*a)
	}

}

func main() {
	division(3, 3)
	division(3, 0)
	notDebug("random string")
	notDebug("debug")
	chekPaswword("password")
	chekPaswword("six")
	var a *int // создали указатель через var по умолчанию nil
	b := 10
	c := &b
	printPointer(c)
	printPointer(a) // ничего не выводит, так как а = nil

}
