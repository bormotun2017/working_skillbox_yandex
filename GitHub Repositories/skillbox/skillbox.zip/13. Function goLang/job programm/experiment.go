package main

import "fmt"

func ZeroPointer(x *int) {
	*x = 0
}

func main() {
	a := 10
	ZeroPointer(&a)
	fmt.Println(a)

}
