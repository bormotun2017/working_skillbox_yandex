package main

import "fmt"

// Напишите функцию, которая на вход получает число и возвращает true, если число четное, и false, если нечётное.
// Рекомендация
// Программа запрашивает у пользователя или генерирует случайное число,
// передает в функцию в качестве аргумента и выводит в консоль результат её работы.
func evenNumber(x int) (y bool) { // принимаем int , возвращаем bool
	if x%2 == 0 {
		y = true
	} else {
		y = false
	}
	fmt.Println(y)
	return // возврат
}
func main() {
	var x int
	fmt.Println("Введите число")
	fmt.Scan(&x)
	fmt.Println("если число четное вернется true, если нечетное false")
	evenNumber(x)

}
