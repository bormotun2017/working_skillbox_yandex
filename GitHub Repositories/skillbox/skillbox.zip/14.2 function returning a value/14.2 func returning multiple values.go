package main

import (
	"fmt"
	"math"
	"math/rand"
	"time"
)

// Напишите программу, которая с помощью функции генерирует три случайные точки в двумерном пространстве (две координаты),
// а затем с помощью другой функции преобразует эти координаты по формулам: x = 2 × x + 10, y = −3 × y − 5.
func point2D() (x int, y int) { // возвращаем координаты

	x = rand.Intn(math.MaxInt8-math.MinInt8) + math.MinInt8 // генератор случайных чисел в пределах int 8
	y = rand.Intn(math.MaxInt8-math.MinInt8) + math.MinInt8

	return
}
func GitConvert(x int, y int) (a int, b int) { // принимает x,y возвращает a,b
	a = 2*x + 10
	b = -3*y - 5
	return
}
func main() {
	rand.Seed(time.Now().UnixNano()) // задаем рандомайзер
	x1, y1 := GitConvert(point2D())  // передаем в функ GitConvert результат функ point2D
	fmt.Println(x1, y1)
	x2, y2 := GitConvert(point2D())
	fmt.Println(x2, y2)
	x3, y3 := GitConvert(point2D())
	fmt.Println(x3, y3)

}
