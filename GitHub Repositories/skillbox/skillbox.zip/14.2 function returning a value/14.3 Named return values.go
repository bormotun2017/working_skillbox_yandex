package main

import "fmt"

// Напишите программу, которая на вход получает число, затем с помощью двух функций преобразует его.
// Первая умножает, а вторая прибавляет число, используя именованные возвращаемые значения.
func multiplication(n int) (x int) {
	x = n * 10
	return
}
func addition(n int) (x int) {
	x = n + 10
	return
}
func main() {
	var number int
	fmt.Println("Введите число для преобразования")
	fmt.Scan(&number)
	fmt.Println("Число после функции умножения")
	number = multiplication(number)
	fmt.Println(number)
	fmt.Println("Число после функции сложение")
	number = addition(number)
	fmt.Println(number)

}
