package main

import (
	"fmt"
	"math/rand"
	"time"
)

func distance(x, y int) { // функ. считает разницу x и y возвращает на результате вывод
	fmt.Println(x - y)
}
func distanceNew(x1, y1, x2, y2 int) {
	fmt.Println(x1 - x2)
	fmt.Println(y1 - y2)

}

func getRandomPoint(n int) int { // функ возвращает параметр int
	return rand.Intn(n) // вычисляет random от переданного в нее n
}
func getRandom2DPoint(n1, n2 int) (int, int) { // функ возвращает 2 хначения int
	return rand.Intn(n1), rand.Intn(n2) // return(возвращает значения)
}

func main() {
	rand.Seed(time.Now().UnixNano()) // задаем рандомайзер
	x := getRandomPoint(10)          // присваиваем x значеие функ с аргументом 10
	y := getRandomPoint(20)          // присваиваем y значеие функ с аргументом 20

	distance(x, y)                                   // передаем x и y в функ. distance, а она возвращает вывод x-y
	distance(getRandomPoint(10), getRandomPoint(20)) // а можно вот так без переменных
	fmt.Println("========================")

	z := getRandomPoint(30) // используем другие переменные
	w := getRandomPoint(40)
	distance(z, w)
	fmt.Println("========================")

	x1, y1 := getRandom2DPoint(10, 20) //присваиваем переменным результат выполнения функции с нашими параметрами
	x2, y2 := getRandom2DPoint(10, 20)
	distanceNew(x1, y1, x2, y2) // передаем x1,y1 и x2,y2 в функ. distanceNew, а она возвращает вывод

}
