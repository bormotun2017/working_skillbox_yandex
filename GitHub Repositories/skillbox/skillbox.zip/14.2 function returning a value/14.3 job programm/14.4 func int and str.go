package main

import (
	"fmt"
	"math/rand"
	"time"
)

func getRandomNumberAndString(n int) (int, string) { //на входе 1 арг, на выходе 2
	rand.Seed(time.Now().UnixNano()) // задаем рандомайзер
	return rand.Intn(n), "hello"     // возвращаем 2 аргумента. 1й - int,2й - string
}
func main() {
	fmt.Println(getRandomNumberAndString(10)) // передаем в функ 10 и выводим результат
	fmt.Println("==============")
	x, str := getRandomNumberAndString(10) // присваиваем переменным значние функ
	fmt.Println("int", x)                  // выводим 1ю
	fmt.Println("string", str)             //выводим вторую

}
