package main

import "fmt"

func multipleIncrement(x, y, z int) (a, b, c int) { // принимаем 3 арг, возвращаем 3 арг
	a = x + 1 //переменные создаются сами после описания выше
	b = y + 1
	c = z + 1
	return // возвращаем a,b,c

}
func main() {

	fmt.Println(multipleIncrement(10, 20, 30))
}
