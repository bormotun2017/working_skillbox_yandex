package main

import "fmt"

func strange() (b int) { //ничё не принимает, но возвращает b int
	return
}
func main() {
	fmt.Println(strange()) // вернет b по умолчанию 0

}
