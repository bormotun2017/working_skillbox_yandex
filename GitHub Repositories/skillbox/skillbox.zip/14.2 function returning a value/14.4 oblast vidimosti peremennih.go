package main

import "fmt"

// Напишите программу, в которой будет три функции, попарно использующие разные глобальные переменные.
// Функции должны прибавлять к поданному на вход числу глобальную переменную и возвращать результат.
// Затем вызовите по очереди три функции, передавая результат из одной в другую.
var (
	sum1 = 100
	sum2 = 200
	sum3 = 300
)

func f1(n int) (x int) {
	x = n + sum1
	return
}
func f2(n int) (x int) {
	x = n + sum2
	return
}
func f3(n int) (x int) {
	x = n + sum3
	return
}

func main() {
	var number int
	fmt.Println("Введите число")
	fmt.Scan(&number)
	fmt.Println("результат первой функции", f1(number))
	fmt.Println("результат второй функции", f2(number))
	fmt.Println("результат третьей функции", f3(number))
	fmt.Println("===================")
	fmt.Printf("результат передачи из 1й во 2ю и в 3ю\n", f3(f2(f1(number))))

}
