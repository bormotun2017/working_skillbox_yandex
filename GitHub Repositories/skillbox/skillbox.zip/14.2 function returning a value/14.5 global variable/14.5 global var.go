package main

import "fmt"

const c = 100 //константа

var a = 50 //глобальная

func f1(x int) int { // на входе int на выходе int
	return x - c
}
func f2(y int) int { // на входе int на выходе int
	return y - a
}
func f3(y int, d *int) int { // на входе int на выходе int. передаем
	//указатель на переменную d из func main
	return y - *d
}
func peek(a int) (c int) { // func. будет работать с локальной перем c а не с константой
	c = a + c
	return
}

func main() {
	d := 75
	fmt.Println(f1(10))
	fmt.Println("==========")
	fmt.Println(f2(10))
	fmt.Println("==========")
	fmt.Println(f3(10, &d)) // передаем указатель d в func f3
	fmt.Println("==========")
	fmt.Println(peek(10))

}
