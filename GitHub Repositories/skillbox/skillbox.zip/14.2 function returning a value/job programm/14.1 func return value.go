package main

import (
	"fmt"
	"math/rand"
	"time"
)

func distance(x, y int) { // функ. считает разницу x и y возвращает на результате вывод
	fmt.Println(x - y)
}
func getRandomPoint(n int) int { // функ возвращает параметр int
	return rand.Intn(n) // вычисляет random от переданного в нее n
}

func main() {
	rand.Seed(time.Now().UnixNano()) // задаем рандомайзер
	x := getRandomPoint(10)          // присваиваем x значеие функ с аргументом 10
	y := getRandomPoint(20)          // присваиваем y значеие функ с аргументом 20

	distance(x, y)                                   // передаем x и y в функ. distance, а она возвращает вывод x-y
	distance(getRandomPoint(10), getRandomPoint(20)) // а можно вот так без переменных

	z := getRandomPoint(30)
	w := getRandomPoint(40)
	distance(z, w)

}
