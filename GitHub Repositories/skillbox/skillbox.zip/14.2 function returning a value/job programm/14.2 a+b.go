package main

import "fmt"

func sum(a, b int) int { // функция возвращает значение  типа int
	//fmt.Println(a + b)
	return a + b // возвращает a+b

}
func main() {
	sumAB := sum(10, 20)     // присваивам переменную
	fmt.Println(sumAB)       // выводим
	fmt.Println(sum(10, 20)) // либо так

}
