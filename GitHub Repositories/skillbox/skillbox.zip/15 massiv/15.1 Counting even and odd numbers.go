package main

import "fmt"

// Разработайте программу, позволяющую ввести 10 целых чисел, а затем вывести из них количество чётных и нечётных чисел.
// Для ввода и подсчёта используйте разные циклы.
// Для введённых чисел 1, 1, 1, 2, 2, 2, 3, 3, 3, 4 программа должна вывести: чётных — 4, нечётных — 6.
func main() {
	var arr [10]int
	fmt.Println("Введите 10 целых чисел")
	for i := 0; i < len(arr); i++ {
		fmt.Scan(&arr[i]) // заполняем массив
	}
	countEvent := 0
	countNotEven := 0
	for i, _ := range arr {
		if arr[i]%2 == 0 {
			countEvent++
		} else {
			countNotEven++
		}
	}
	fmt.Println("четных - ", countEvent)
	fmt.Println("нечетных - ", countNotEven)

}
