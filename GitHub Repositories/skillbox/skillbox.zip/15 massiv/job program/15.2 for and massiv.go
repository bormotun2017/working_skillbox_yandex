package main

import "fmt"

func main() {
	var rain [10]int                 //описываем массив
	for i := 0; i < len(rain); i++ { // пока i меньше последнего индекса массива
		fmt.Printf("Введите количество осадков в %v году", 2011+i)
		fmt.Scan(&rain[i]) //заполняем массив

	}
	for i := 0; i < len(rain); i++ {
		fmt.Printf("год: %v осадков: %v\n", 2011+i, rain[i]) // выводим массив
	}

}
