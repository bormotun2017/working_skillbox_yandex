package main

import "fmt"

func main() {
	var arr [100]int // описывам массив на 100 элементов
	var n int        // счетчик введенных чисел
	fmt.Println("сколько чисел вы хотите ввести:")
	fmt.Scan(&n)
	for i := 0; i < n; i++ {
		fmt.Printf("arr[%v]=", i)
		fmt.Scan(&arr[i])
	}
	fmt.Println("Вывод")
	for i := 0; i < (n+1)/2; i++ { // выводим только четные элементы
		index := i*2 + 1                              // индекс четного элемента, так как массив идет с 0
		fmt.Printf("arr[%v]=%v\n", index, arr[index]) // выводим массив
	}

}
