package main

import "fmt"

func main() {
	var names [2]string //массив названия городов
	var citizens [2]int // массив количество жителей
	for i, _ := range names {
		fmt.Println("Введите название города")
		fmt.Scan(&names[i]) // заполняем города
		fmt.Println("Введите количество жителей")
		fmt.Scan(&citizens[i]) // заполняем жителей
	}
	fmt.Println("=================")
	for i, citizen := range citizens {
		if citizen > 100000 { // если жителей больше 1000000 выводим название города
			fmt.Println(names[i])
		}
	}

}
