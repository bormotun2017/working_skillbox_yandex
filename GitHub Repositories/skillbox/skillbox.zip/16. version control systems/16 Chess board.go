package main

import (
	"fmt"
)

func main() {
	fmt.Println("Эта программа выводит шахматную доску заданных размеров")
	var height, width int
	fmt.Println("Введите ширину")
	fmt.Scan(&width)
	fmt.Println("Введите высоту")
	fmt.Scan(&height)

	chessWrite(height, width)
}

func chessWrite(height int, width int) {
	for countHeight := 1; countHeight <= height; countHeight++ {
		if countHeight%2 == 0 {
			for countWidht := 0; countWidht <= width; countWidht += 2 {
				fmt.Print("*")
				fmt.Print(" ")
			}
		} else {
			for countWidht := 2; countWidht <= width; countWidht += 2 {
				fmt.Print(" ")
				fmt.Print("*")
			}
		}
		fmt.Println()
	}
}
