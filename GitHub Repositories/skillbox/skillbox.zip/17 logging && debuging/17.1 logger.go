package main

import (
	log "github.com/sirupsen/logrus"
)

// Выведите в консоль в формате json информацию о состоянии переменных `a` и `i`
// после вычисления значения переменной `a` на каждой итерации цикла в приведённом ниже примере.
func init() {
	log.SetFormatter(&log.JSONFormatter{})
}

var a int

func main() {
	for i := 0; i <= 10; i++ {
		a += i * i
		log.Info("i= ", i, " ", "a= ", a)
		//log.Infof("i = %v", i)

	}
}
