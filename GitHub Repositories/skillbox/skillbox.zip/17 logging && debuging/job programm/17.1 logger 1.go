package main

import (
	"fmt"
	"time"
)

func runAndWait() int {
	time.Sleep(time.Second * 1) // таймер. функ спит 1 секунду после вызова
	return 10                   // возвращаем число 10

}
func main() {
	for i := 0; i < 5; i++ {
		a := runAndWait()       // a:=10(результат нашей функ)
		fmt.Println(time.Now()) // выводим текущее время
		fmt.Println("runAndWait finished...")
		fmt.Println("result", a) // вывод результата

	}
	fmt.Println("done")

}
