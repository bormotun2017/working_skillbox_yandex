package main

import (
	"fmt"
	log "github.com/sirupsen/logrus" // замена стандартного log на logrus
	"time"
)

func runAndWait2() int {
	time.Sleep(time.Second * 1) // таймер. функ спит 1 секунду после вызова
	return 10                   // возвращаем число 10

}
func main() {
	/*	file, err := os.OpenFile("test.log", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666) // созд. файл.
		//os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666 флаги открытия файла. создаем или пишем в него или открываем
		//если такой файл есть. для чтения и для запис
		if err != nil {
			log.Fatalf("error while opening a file: %v\n", err)
		}
		log.SetOutput(file) //записываем file все что ниже по тексту */
	for i := 0; i < 5; i++ {
		a := runAndWait2()

		log.WithTime(time.Now()) // лог текущего времени
		log.Info("runAndWait2")
		log.Infof("result: %d", a) // лог результата функ
		log.Debugf("func", runAndWait2())
		log.Error()

	}
	fmt.Println("done")

}
