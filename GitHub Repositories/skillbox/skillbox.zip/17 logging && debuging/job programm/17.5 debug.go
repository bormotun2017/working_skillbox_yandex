package main

import (
	"fmt"
	log "github.com/sirupsen/logrus" // замена стандартного log на logrus
	"time"
)

func runAndWait4(a, b int) int {
	c := a + b
	log.WithFields(log.Fields{
		"a": a,
		"b": b,
	}).Infof("c=%d", c)
	time.Sleep(time.Millisecond * 1) // таймер. функ спит 1 секунду после вызова
	return c                         // возвращаем c

}
func init() { // вызывается всегда перед запуском майн, если таковая имеется
	log.SetFormatter(&log.JSONFormatter{}) // стиль форматирования логгера. j общепринятый стиль
	log.SetLevel(log.InfoLevel)            // выводит только сообщения  warning и уровнем выше, нижние отсекает

}
func main() {
	/*	file, err := os.OpenFile("test.log", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666) // созд. файл.
		//os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666 флаги открытия файла. создаем или пишем в него или открываем
		//если такой файл есть. для чтения и для запис
		if err != nil {
			log.Fatalf("error while opening a file: %v\n", err)
		}
		log.SetOutput(file) //записываем file все что ниже по тексту */
	for i := 0; i < 100; i++ {
		a := runAndWait4(i, i*2)

		//log.WithTime(time.Now()) // лог текущего времени не нужен, так как сделали формат логгера
		log.Info("runAndWait2")
		log.Infof("result: %d", a) // лог результата функ
		if i > 90 {
			//log.Warn("close to 100") // вызываем уровень warning, предупреждаем, что подошли к 100
			log.WithFields(log.Fields{"i": i}).Warn("close to 100..") //добавляет новое поле  в наш лог "i"
		}

		if i == 99 {
			log.Fatal("reached 100") // завершает работу программы выводя сообщение, делая os.Exit
			//	log panic() // не завершает сразу работу программы

		}

	}
	fmt.Println("done")

}
