package main

import "fmt"

func doPanic(a int) {
	if a > 1 {
		doPanic(a - 1) // рекурсия. функция вызывает сама себя
	}
	panic(a)
}
func main() {
	var s string //первый breakpoint начало программы
	s = "hello world"
	fmt.Println(s)
	var ii int // ну и пошалгово разбираем программу
	ii = 10
	fmt.Println(ii)
	fmt.Println("i am denuging now ")
	doPanic(5)

}
