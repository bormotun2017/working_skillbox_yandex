package main

import "fmt"

var a int

func changeA(b int) {
	a = b

}
func main() {
	for i := 0; i < 10; i++ {
		changeA(i) // условный breakpoint правая кнопка мыши.... i>5.
		//сразу попадаем в интересующий нас кусок кода
		if i > 5 {
			fmt.Println("hello")
		}

	}

}
