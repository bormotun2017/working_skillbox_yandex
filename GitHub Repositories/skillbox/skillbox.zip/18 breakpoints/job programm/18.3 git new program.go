package main

import "fmt"

func sumAB(a, b int) int {
	return (a + b) / 2

}
func diffAB(a, b int) int {
	return a - b

}
func multAB(a, b int) int {
	return a * b

}

func main() {
	fmt.Println(10)

}
