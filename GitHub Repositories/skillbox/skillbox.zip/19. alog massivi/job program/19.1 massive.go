package main

import "fmt"

//Задание 1. Слияние отсортированных массивов
//Напишите функцию, которая производит слияние двух отсортированных массивов длиной
//четыре и пять в один массив длиной девять.

func arr(arr1 [4]int, arr2 [5]int) (arr3 [9]int) {
	for i := 0; i < len(arr3); i++ {
		if i < 4 {
			arr3[i] = arr1[i]
		} else {
			arr3[i] = arr2[i-4]
	}

	}
	return arr3

}
func main() {
	arr1 := [4]int{10, 20, 30, 40}
	arr2 := [5]int{50, 60, 70, 80, 90}
	fmt.Println(arr(arr1, arr2))

}
