package main

import "fmt"

func main() {

	var delivery int
	var discount int
	var price int
	fmt.Println("Калькулятор стоимости товара со скидеой.")
	fmt.Println("Введите стоимость товара")
	fmt.Scan(&price)
	fmt.Println("Введите стоимость доставки")
	fmt.Scan(&delivery)
	fmt.Println("Введите стоимость скидки")
	fmt.Scan(&discount)
	result := price + delivery - discount
	fmt.Println("Стоимость Товара: ", price)
	fmt.Println("Стоимость доставки: ", delivery)
	fmt.Println("Размер скидки: ", discount)
	fmt.Println("---------")
	fmt.Println("Итого: :", result)
}
