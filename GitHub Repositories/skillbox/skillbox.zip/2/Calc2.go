package main

import "fmt"

func main() {
	timeСhangeMin := 400
	timeClient := 2
	timeСashier := 4
	amountClients := timeСhangeMin / (timeClient + timeСashier)
	fmt.Println("Расчёт количества клиентов, обслуживаемых за смену.")
	fmt.Println("Введите длительность смены в минутах: ", timeСhangeMin)
	fmt.Println("Сколько минут клиент делает заказ: ", timeClient)
	fmt.Println("Сколько минут кассир собирает заказ: ", timeСashier)
	fmt.Println("-----Считаем-----")
	fmt.Println("За смену длиной ", timeСhangeMin, "минут кассир успеет обслужить ", amountClients, "клиентов.")
}
