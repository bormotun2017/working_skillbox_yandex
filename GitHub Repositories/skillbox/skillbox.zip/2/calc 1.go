package main

import "fmt"

func main() {
	delivery := 350
	discount := 700
	price := 6400
	result := price + delivery - discount
	fmt.Println("Калькулятор стоимости товара со скидеой.")
	fmt.Println("Стоимость Товара: ", price)
	fmt.Println("Стоимость доставки: ", delivery)
	fmt.Println("Размер скидки: ", discount)
	fmt.Println("---------")
	fmt.Println("Итого: :", result)
}
