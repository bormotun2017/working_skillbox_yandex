package main

import "fmt"

func main() {
	totalAmount := 4_000_000
	porchesРouse := 10
	apartments := 40
	amountInvoice := totalAmount / (porchesРouse * apartments)
	fmt.Println("Расчёт стоимости ремонта для каждой квартиры.")
	fmt.Println("Сумма, указанная в квитанции:", totalAmount, "рублей.")
	fmt.Println("Подъездов в доме:", porchesРouse)
	fmt.Println("Квартир в каждом подъезде: ", apartments)
	fmt.Println("-----Результат-----")
	fmt.Println("Каждая квартира должна платить по", amountInvoice, "рублей.")
}
