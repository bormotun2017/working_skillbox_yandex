package main

import "fmt"

func main() {
	/*
		This is cimment too
	*/
	fmt.Println("Hello", "welcom") // This is comment
	fmt.Println(42)
}
