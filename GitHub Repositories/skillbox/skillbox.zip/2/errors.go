package main

import "fmt"

func main() {
	fmt.Println("Hello, I'm Egor.")
	fmt.Println("I'm 34", "years old.")
	fmt.Println("Looking forward to the next lesson!")
}
