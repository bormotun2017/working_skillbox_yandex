package main

import "fmt"

func main() {
	fmt.Println("Введите целое число")

	var a int
	fmt.Scan(&a)
	a = a * a
	fmt.Println("Квадрат введенного числа равен: ", a)

}
