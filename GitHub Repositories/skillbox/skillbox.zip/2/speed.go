package main

import "fmt"

func main() {
	var circleNumber int = 4
	var surnameRacer = "Шумахер"
	var motor int = 254
	var wheels int = 93
	var steeringWheel int = 49
	var wind int = 21
	var rain int = 17
	speed := motor + wheels + steeringWheel - wind - rain
	fmt.Println("===================")
	fmt.Println("Супер гонки. Круг", circleNumber)
	fmt.Println()
	fmt.Println("===================")
	fmt.Print("Водитель:", surnameRacer, "(", speed, ")\n")
	fmt.Println("Скорость:", speed)
	fmt.Println()
	fmt.Println("-------------------")
	fmt.Println("Оснащение")
	fmt.Print("Двигатель: +", motor, "\n")
	fmt.Print("Колеса: +", wheels, "\n")
	fmt.Print("Руль: +", steeringWheel, "\n")
	fmt.Println()
	fmt.Println("-------------------")
	fmt.Println("Действия плохой погоды")
	fmt.Print("Ветер: -", wind, "\n")
	fmt.Print("Дождь: -", rain, "\n")

}
