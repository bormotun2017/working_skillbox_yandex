package main

import "fmt"

func main() {
	fmt.Println("Привет! Введите целое число")

	var i int
	fmt.Scan(&i)

	fmt.Println("Введенное вами число:", i)
}
