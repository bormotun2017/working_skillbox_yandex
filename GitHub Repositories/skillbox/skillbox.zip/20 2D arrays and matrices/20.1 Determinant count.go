package main

import "fmt"

const row = 3
const col = 3

// Напишите функцию, вычисляющую определитель матрицы размером 3 × 3.
// det(A)=a11*a22*a33+a31*a12*a23+a21*a32*a13-a31*a22*a13-a21*a12*a33-a11*a23*a31
func Determinate(a [row][col]int) {
	b := (a[0][0] * a[1][1] * a[2][2]) + (a[0][1] * a[1][2] * a[2][0]) + (a[0][2] * a[1][0] * a[2][1]) - (a[0][2] *
		a[1][1] * a[2][0]) - (a[0][0] * a[1][2] * a[2][1]) - (a[0][1] * a[1][0] * a[2][2])
	fmt.Println(b)

}
func main() {
	matrix := [row][col]int{
		{1, 2, 3},
		{3, 2, 1},
		{2, 1, 3},
	}
	Determinate(matrix)

}
