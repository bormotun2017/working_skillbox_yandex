package main

import "fmt"

// Напишите функцию, умножающую две матрицы размерами 3 × 5 и 5 × 4.
const col1 = 3
const row1 = 5
const col2 = 5
const row2 = 4

// 1 2 3 4 5        1 2 3 4		c[1,1]=a[1,1]*b[1,1]+a[1,2]*b[1,2]+a[1,3]*b[1,3]+a[1,4]*b[1,4]+a[1,5]*b[1,5]
// 1 2 3 4 5		1 2 3 4
// 1 2 3 4 5		1 2 3 4
//
//	1 2 3 4
//	1 2 3 4
func multiplication(arr1 [col1][row1]int, arr2 [col2][row2]int) (arr3 [col1][row2]int) { //функ умножения матриц

	for i := 0; i < len(arr3); i++ { //пробегаем наш массив
		for j := 0; j < len(arr3[i]); j++ {

			for b := 0; b < col2; b++ { //ловим индекс столбца и строки первого и второго массива

				arr3[i][j] = arr3[i][j] + arr1[i][b]*arr2[b][j] // заполняем
			}
			fmt.Print(arr3[i][j], " ") //выводим строку

		}
		fmt.Println("") // выводим в виде матрицы
	}

	return arr3
}
func main() {
	arr1 := [col1][row1]int{ //первый массив
		{1, 2, 3, 4, 5},
		{1, 2, 3, 4, 5},
		{1, 2, 3, 4, 5},
	}

	arr2 := [col2][row2]int{ //второй массив
		{1, 2, 3, 4},
		{1, 2, 3, 4},
		{1, 2, 3, 4},
		{1, 2, 3, 4},
		{1, 2, 3, 4},
	}
	for i := 0; i < len(arr1); i++ { //пробегаем наш массив
		for j := 0; j < len(arr1[i]); j++ {

			fmt.Print(arr1[i][j], " ") //выводим строку

		}
		fmt.Println("") // выводим в виде матрицы
	}
	fmt.Println("===================")
	for i := 0; i < len(arr2); i++ { //пробегаем наш массив
		for j := 0; j < len(arr2[i]); j++ {

			fmt.Print(arr2[i][j], " ") //выводим строку

		}
		fmt.Println("") // выводим в виде матрицы
	}
	fmt.Println("===================")
	multiplication(arr1, arr2)

}
