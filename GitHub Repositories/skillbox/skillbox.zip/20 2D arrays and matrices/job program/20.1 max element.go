package main

import "fmt"

const count = 4

func maximum(input [count]int) int {
	max := input[0]                   //присваиваем максимальному элементу 1й эл массива
	for i := 0; i < len(input); i++ { // цикл до конца массива
		if input[i] > max { // условие для нахождения максимумуа
			max = input[i] // присваиваем переменной значение макс
		}

	}
	return max // возвращаем макс
}
func main() {
	arr := [4]int{1, 2, 3, 4}
	fmt.Println(maximum(arr)) //выводим макс нашего массива

}
