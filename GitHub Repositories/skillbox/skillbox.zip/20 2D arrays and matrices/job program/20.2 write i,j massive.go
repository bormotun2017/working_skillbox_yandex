package main

import "fmt"

const size = 4
const rows = 3

func main() {
	matrix := [rows][size]int{ //описываем 2х мерный массив
		{1, 0, 1, 0},
		{2, 3, 3, 2},
		{4, 5, 5, 5},
	}
	//fmt.Println(matrix)
	for i := 0; i < len(matrix); i++ { // вывод 2х м массива. len(matrix)=rows, длина строк
		fmt.Println(matrix[i])
	}
	for i := 0; i < len(matrix); i++ {
		for j := 0; j < len(matrix[i]); j++ { //вложенный цикл для столбцов
			fmt.Println(matrix[i][j]) // поэлементынй вывод 2х мерного массива

		}

	}
}
