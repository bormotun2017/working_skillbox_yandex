package main

import "fmt"

const rows = 3
const cols = 5

func maximum(input [cols]int) int { //функ находит макс эл в одномер массиве
	max := input[0]
	for i := 0; i < len(input); i++ {
		if input[i] > max {
			max = input[i]
		}
	}
	return max
}
func findMaxInMatrix(matrix [rows][cols]int) [rows]int {
	var result [rows]int               //объявляем массив который будем возвращать
	for i := 0; i < len(matrix); i++ { //делим массив на строки
		lMax := maximum(matrix[i]) //Lmax нашего массива передаем в функ maximum
		result[i] = lMax           //заполняем наш массив макс элементами
	}
	return result
}
func summAll(matrix [rows][cols]int) int { // функ считает сумму всех элементов массива
	summ := 0
	for i := 0; i < len(matrix); i++ { // пробегаем по кол ву строк
		for j := 0; j < len(matrix[i]); j++ { //пробегаем по каждому элементу строки строке
			summ = summ + matrix[i][j]

		}
	}
	return summ
}
func sumNotEven(matrix [rows][cols]int) int { // считает сумму нечетных столбцов
	sum := 0
	for i := 0; i < len(matrix); i++ {
		for j := 0; j < len(matrix[i]); j++ {
			if j%2 != 0 { //если номер колонки нечетный
				sum += matrix[i][j]
			}

		}
	}
	return sum
}
func main() {
	matrix := [rows][cols]int{
		{1, 2, 3, 4, 5},
		{3, 2, 10, 100, 102},
		{40, 50, -10, -20, -30},
	}
	fmt.Println(findMaxInMatrix(matrix))
	fmt.Println(summAll(matrix))
	fmt.Println(sumNotEven(matrix))
}
