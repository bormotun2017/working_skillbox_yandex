package main

import "fmt"

const rows = 3
const cols = 4

func sumMatrice(A [rows][cols]int, B [rows][cols]int) [rows][cols]int { //сумма 2х массивов

	for i := 0; i < len(A); i++ {
		for j := 0; j < len(A[i]); j++ {
			A[i][j] = A[i][j] + B[i][j] //складываем обя массвиа в первый
		}
	}
	return A
}

func diagonalSum(A [rows][cols]int) int { // сумма диагонали в один цикл
	sum := 0
	for i := 0; i < len(A); i++ {
		sum = sum + A[i][i] // диагональ

	}
	return sum

}
func transpose(A [rows][cols]int) [cols][rows]int { // перевертывание матрицы за 3/4 ,будет 4/3
	var transposed [cols][rows]int
	for i := 0; i < len(A[0]); i++ { //итерация по нулевому элементу матрицы A
		for j := 0; j < len(A); j++ { //итерация по размерности матрицы A
			transposed[i][j] = A[j][i] //

		}

	}
	return transposed
}
func printInOneCicle(m [rows][cols]int) { // функ с одним циклом
	for i := 0; i < rows*cols; i++ { //итерирование в один цикл
		//123
		//234 -> 123234 //рассматриваем матрицу как одномерный массив
		row := i / cols // индекс строки
		col := i % cols //индекс столбца
		fmt.Println(m[row][col])

	}

}

func main() {
	matrix := [rows][cols]int{
		{10, 10, 10, 10},
		{10, 20, 10, 20},
		{-10, -20, -10, -10},
	}
	fmt.Println(sumMatrice(matrix, matrix))
	fmt.Println(diagonalSum(matrix))
	fmt.Println(transpose(matrix))
	printInOneCicle(matrix)

	//summ
	//ddiagonal
	//tranpose

}
