package main

import (
	"fmt"
)

// Напишите функцию, производящую следующие вычисления.
// S = 2 × x + y ^ 2 − 3/z, где x — int16, y — uint8, a z — float32.
// Тип S должен быть во float32.
func calculation(s float32) float32 {
	var (
		x int16
		y uint8
		z float32
	)
	fmt.Println("Введите x")
	fmt.Scan(&x)
	fmt.Println("Введите y")
	fmt.Scan(&y)
	fmt.Println("Введите z")
	fmt.Scan(&z)
	s = 2*float32(x) + float32(y*y) - 3/z
	return s
}
func main() {
	var s float32

	fmt.Println("2 × x + y ^ 2 − 3/z = ", calculation(s))

}
