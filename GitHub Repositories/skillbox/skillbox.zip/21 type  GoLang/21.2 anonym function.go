package main

import "fmt"

// Напишите функцию, которая на вход принимает функцию вида A func (int, int) int,
// а внутри оборачивает и вызывает её при выходе (через defer).
//
// Вызовите эту функцию с тремя разными анонимными функциями A. Тела функций могут быть любыми,
// но главное, чтобы все три выполняли разное действие.
var a, b int

func deferWrite(A func(a int, b int) (string, int)) {

	defer func() { //отложенно вызываем функ через defer

		fmt.Println(A(a, b)) // вывод

	}()
}
func main() {

	fmt.Println("Введите a") //блок ввода
	fmt.Scan(&a)
	fmt.Println("Введите b")
	fmt.Scan(&b)

	deferWrite(func(a int, b int) (string, int) { return "a + b = ", a + b }) //передаем функ в функ
	deferWrite(func(a int, b int) (string, int) { return "a - b = ", a - b })
	C := func(a int, b int) (string, int) { return "a * b = ", a * b } // делаем через переменную
	deferWrite(C)

}
