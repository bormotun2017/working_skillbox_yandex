package main

import "fmt"

func main() {
	var a int8
	a = 127
	fmt.Println(a + 1) //переполнение типа int8, результат -128

}
