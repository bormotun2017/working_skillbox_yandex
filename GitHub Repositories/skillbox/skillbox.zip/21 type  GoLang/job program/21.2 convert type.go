package main

import "fmt"

func sumDifferentTypes(a int64, b float64) float64 {

	return float64(a) + b //приведение типа

}
func sumDifferentTypes2(a int64, b float64) int64 {

	return a + int64(b) //округдяет тип в инт, отбрасывая 0.3

}

func main() {
	fmt.Println(sumDifferentTypes(10, 10.3))
	fmt.Println(sumDifferentTypes2(10, 10.3))

}
