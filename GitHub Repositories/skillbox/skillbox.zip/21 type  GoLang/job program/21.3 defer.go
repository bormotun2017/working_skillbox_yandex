package main

import "fmt"

func iAcceptFunction(x, y, z int, f func(int, int) int) int { // функ принимает на вход функцию
	return x + f(y, z)

}

func main() {
	fmt.Println(
		iAcceptFunction(10, 20, 30, func(y int, z int) int { return y + z }))
	//объявили функцию прямо в вызове функции

}

//	f := func(x, y int) int { return x + y } //анонимная функция. можно запихнуть функ в перемен
//	fmt.Println(f(10, 15))
