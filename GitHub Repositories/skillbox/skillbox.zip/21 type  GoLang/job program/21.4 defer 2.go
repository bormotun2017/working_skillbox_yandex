package main

import "fmt"

func iAmUsingDefer() {
	defer func() {
		fmt.Println(1)
		fmt.Println(2)
	}() //отложенный вызов функ defer

	//defer fmt.Println("exittting function") // отложенный вызов функ
	fmt.Println("before defer")
}
func main() {
	iAmUsingDefer()
	fmt.Println("DONE")

}
