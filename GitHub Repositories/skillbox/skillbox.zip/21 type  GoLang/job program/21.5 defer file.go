package main

import (
	"fmt"
	log "github.com/sirupsen/logrus"
	"os"
)

func main() {
	f := createFile("defer.txt")
	defer closeFile(f)
	writeFile(f)
}
func createFile(path string) *os.File { //функ создает файл
	log.Println("Creating file")
	f, err := os.Create(path)
	if err != nil {
		log.Fatalf("err while creating file: %v", err)
	}
	return f
}
func writeFile(f *os.File) { // функ запись в файл
	log.Println("Writing file")
	fmt.Fprintln(f, "data") //запись. ничего не возвращаем
}
func closeFile(f *os.File) {
	log.Println("Closing file")
	err := f.Close()
	if err != nil { //если не получилось закрыть файл
		fmt.Fprintf(os.Stderr, "error: %v\n", err) // выводим поток вывода ошибок
		os.Exit(1)                                 // принудительно выходим
	}

}
