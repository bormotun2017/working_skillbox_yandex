package main

import (
	"fmt"
	"math/rand"
	"time"
)

// Заполните массив неупорядоченными числами на основе генератора случайных чисел. Введите число.
// Программа должна найти это число в массиве и вывести, сколько чисел находится в массиве после введённого.
// При отсутствии введённого числа в массиве — вывести 0. Для удобства проверки реализуйте вывод массива на экран.
const n = 10

func find(arr [n]int, value int) (index int) { //поиск в несортированном массиве
	index = -1
	for i := 0; i < n; i++ {
		if arr[i] == value {
			index = i
		}
	}
	if index == -1 { //если не нашли элемент возвращаем 0
		index = 0
	}
	return
}
func main() {
	rand.Seed(time.Now().UnixNano())
	var arr [n]int
	var value, count int
	for i := 0; i < len(arr); i++ {
		arr[i] = rand.Intn(10)

	}
	for i := 0; i < len(arr); i++ {
		fmt.Print(arr[i], " ") //выводим введенный массив

	}
	fmt.Println()
	fmt.Println("Введите число")
	fmt.Scan(&value)
	index := find(arr, value)
	if index == 0 {
		fmt.Println("0")

	} else {
		for i := 0; i < n-1-index; i++ { // выводим массив после искомого элемента
			fmt.Print(arr[index+1+i], " ")
			count++
		}
		fmt.Println()
		fmt.Println("В массиве находится", count, "числа после введенного")
	}

}
