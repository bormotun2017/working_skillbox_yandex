package main

import (
	"fmt"
	"math/rand"
	"time"
)

//const n = 10

func find(a [n]int, value int) (index int) { // принимаем массив и числоб возвращаем индекс
	index = -1
	for i := 0; i < n; i++ {
		if a[i] == value {
			index = i
			break
		}

	}
	return
}
func main() {
	rand.Seed(time.Now().UnixNano()) // генератор случайных чисел
	var a [n]int
	for i := 0; i < n; i++ {
		a[i] = rand.Intn(18 * n) //заполняем массв случайными числами

	}
	value := a[n/2] //ищем число находящееся в массиве
	index := find(a, value)
	fmt.Printf("Индекс %v\n", index)
	value = n * 20 //ищем число не находящееся в массиве
	index = find(a, value)
	fmt.Printf("Индекс %v\n", index)

}
