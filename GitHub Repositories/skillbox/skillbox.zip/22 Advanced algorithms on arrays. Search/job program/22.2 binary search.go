package main

import (
	"fmt"
	"math/rand"
	"time"
)

const n = 10

func main() {
	rand.Seed(time.Now().UnixNano())
	var a [n]int
	for i := 0; i < n; i++ {
		a[i] = 10*i + rand.Intn(10) // заполняем массив по возрастанию
	}
	for i := 0; i < n; i++ {
		fmt.Printf("%v\t", a[i])
	}
	fmt.Println()
	//Ищем число находящееся в массиве
	value := a[rand.Intn(n)]
	fmt.Println(value)
	index := find(a, value)
	fmt.Printf("индекс : %v\n", index)
	//ищем число Не находящееся в массиве
	value = 20 * n
	fmt.Println(value)
	index = find(a, value)
	fmt.Printf("индекс : %v\n", index)

}
func find(a [n]int, value int) (index int) {
	index = -1 // означает, что в нашем массиве такого элемента нет
	min := 0
	max := n - 1
	for max >= min { // пока макс больше мин
		//	for i := 0; i < len(a); i++ { //так тоже можно но не желательно

		middle := (max + min) / 2 // находим значение среднего элемента
		if a[middle] == value {   //если средний индекс равен искомому числу то
			index = middle // искомый индекс равен среднему
			break
		} else if a[middle] > value { // если средний больше искомого
			max = middle - 1 // сдвигаем влево
		} else { // если меньше
			min = middle + 1
		}
	}
	return
}
