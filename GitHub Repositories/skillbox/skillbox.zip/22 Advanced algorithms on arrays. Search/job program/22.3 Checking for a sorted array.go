package main

import (
	"fmt"
	"math/rand"
	"time"
)

const n = 10

func main() {
	rand.Seed(time.Now().UnixNano())
	var a [n]int
	for i := 0; i < n; i++ {
		a[i] = /*10*i + */ rand.Intn(10) // заполняем массив по возрастанию
	}
	fmt.Println(chekSorted(a))

}

func chekSorted(a [n]int) (result bool) { //проверка упорядочен массив или нет
	result = true //предполагаем, что массив упорядочен
	//метод монте карло. если 3 эл массива из первой трети, середины и конца не идут по возрастанию,+
	//значит он не упорядочен. Используется, чтобы не перебирать весь массив
	firstIndex := rand.Intn(n / 3)       //случайный элемент из первой трети массива
	secondIndex := rand.Intn(n/3) + n/3  //случайный элемент из второй трети массива
	thirdIndex := rand.Intn(n/3) + 2*n/3 //случайный элемент из третьей трети массива
	if a[firstIndex] > a[secondIndex] || a[secondIndex] > a[thirdIndex] || a[firstIndex] > a[thirdIndex] {
		//проверка на метод монте карло
		result = false
		fmt.Println("Определили методом Монте-какрло")
		return
	}
	for i := 0; i < n-1; i++ { //n-1, чтобы не вылезти за стек массва
		if a[i+1] < a[i] { // проверка на сортированность .. если нет, то возврааем false
			result = false
			fmt.Println("Определили методом перебора")

			break
		}

	}
	return
}
