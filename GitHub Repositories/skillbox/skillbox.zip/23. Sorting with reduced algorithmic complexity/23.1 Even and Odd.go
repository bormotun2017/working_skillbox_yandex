package main

import "fmt"

// Напишите функцию, которая принимает массив чисел, а возвращает два массива:
// один из чётных чисел, второй из нечётных.
const n = 10

func evenAndOdd(arr [n]int) (arreven, arrodd [n]int) {
	counteven := 0
	countodd := 0

	for i := 0; i < n; i++ {
		if arr[i]%2 == 0 {
			arreven[counteven] = arr[i]
			counteven++ //считаем количество четных
		} else {
			arrodd[counteven] = arr[i]
			countodd++ //считаем количество не четных
		}
	}
	//выводим наши массивы пока не кончатся четные и не четные числа
	for i := 0; i < counteven; i++ {
		fmt.Print(arreven[i], " ")

	}
	fmt.Println()
	for i := 0; i < countodd; i++ {
		fmt.Print(arrodd[i], " ")

	}
	return arreven, arrodd
}
func main() {
	arr := [n]int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
	evenAndOdd(arr)
	//arreven, arrodd := evenAndOdd(arr)
	//fmt.Println(arreven)
	//fmt.Println(arrodd)

}
