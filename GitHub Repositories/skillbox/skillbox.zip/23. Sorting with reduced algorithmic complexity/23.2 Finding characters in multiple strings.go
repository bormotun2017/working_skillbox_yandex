package main

import (
	"errors"
	"fmt"
	"strconv"
	"strings"
	"unicode"
)

// Напишите функцию, которая на вход принимает массив предложений (длинных строк) и массив символов типа rune,
// а возвращает 2D-массив, где на позиции [i][j] стоит индекс вхождения символа j из chars
// в последнее слово в предложении i (строку надо разбить на слова и взять последнее). То есть сигнатура следующая:
// func parseTest(sentences []string, chars []rune)
// sentences := [4]string{"Hello world", "Hello Skillbox", "Привет Мир", "Привет Skillbox"}
// chars := [5]rune{'H','E','L','П','М'}
// Пример вывода результата в первом элементе массива
// 'H' position 0
// 'E' position 1
// 'L' position 9
func array(sentences [4]string, chars [5]rune) (index [4][2]string, err error) {
	if len(sentences) == 0 || len(chars) == 0 {
		return index, errors.New("один из массивов или оба пустые") //возвращаем ошибку если массивы пустые

	}

	for i := 0; i < len(sentences); i++ { //просматриваем массив

		ss := strings.Split(sentences[i], " ") // получаем последнее слово строки
		lastWord := ss[len(ss)-1]
		lastIndexLower := strings.IndexRune(lastWord, unicode.ToLower(chars[i])) // находит последнее вхождение
		//если руна в нижнем регистре
		lastIndexUpper := strings.IndexRune(lastWord, unicode.ToUpper(chars[i])) // находит последнее вхождение
		//если руна в верхнем регистре
		if lastIndexUpper > -1 { // заполянем наш новый массив в этом же цикле
			// если в слове встречается наша руна в любом регистре
			index[i][0] = strconv.QuoteRune(chars[i]) + " position "
			index[i][1] = strconv.Itoa(lastIndexUpper)
		} else if lastIndexLower > -1 {
			index[i][0] = strconv.QuoteRune(chars[i]) + " position "
			index[i][1] = strconv.Itoa(lastIndexLower)
		} else {
			index[i][0] = strconv.QuoteRune(chars[i]) + " position "
			index[i][1] = strconv.Itoa(-1)
		}
		//выводим наш массив в том же цикле
		fmt.Printf(index[i][0])

		fmt.Printf(index[i][1])
		fmt.Println()

	}

	//	fmt.Println(index)

	return
}

func main() {
	sentences := [4]string{"Hello world", "Hello Skillbox", "Привет Мир", "Привет Skillbox"}
	chars := [5]rune{'D', 'X', 'L', 'П', 'X'}
	array(sentences, chars)

}
