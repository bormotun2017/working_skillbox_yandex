package main

import "fmt"

const size = 10

// a[i]<=a[i+1] сортировка по возрастанию
func sort(input [size]int64) [size]int64 { //сортировка поиском мин элемента
	for i := 0; i < size; i++ { //бежим по массиву
		var minIdx = i
		for j := i; j < size; j++ { // бежим по массиву после i
			if input[j] < input[minIdx] {
				minIdx = j //т.е. справа был элемент меньше нашего минимума
			}
		}
		input[i], input[minIdx] = input[minIdx], input[i] //меняем элементы местами
	}
	return input

}
func main() {
	a := [size]int64{10, 39, 2, 3, 10, 99, 5, 45, 54, 31}
	fmt.Println(a)

	b := sort(a) //функ сортировки
	fmt.Println("====Sorted====")
	fmt.Println(b)

}
