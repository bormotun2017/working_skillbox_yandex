package main

import "fmt"

func generalSum(s ...int) int { // описание неограниченнного количества аргументов функ
	//в даммном случае s-массив из неогранич кол-ва интов
	fmt.Println("first=", s[0]) //обращение по индексу эл массива
	fmt.Println("second=", s[1])

	ss := 0
	for _, v := range s { // пробегаем массив s до конца
		ss = ss + v
	}
	return ss
}
func conditionalCalculate(op string, x ...int) int { // функ с условием принятого аргумента
	var result int
	if op == "+" { // если на входе + складываемм
		for _, v := range x {
			result = result + v
		}

	}
	if op == "*" { // если на входе * умножаем
		result = 1
		for _, v := range x {
			result = result * v

		}
	}
	return result
}

func main() {
	fmt.Println(generalSum(1, 2, 3, 4, 5, 6))
	fmt.Println(conditionalCalculate("*", 1, 2, 3, 4, 5, 6))

}
