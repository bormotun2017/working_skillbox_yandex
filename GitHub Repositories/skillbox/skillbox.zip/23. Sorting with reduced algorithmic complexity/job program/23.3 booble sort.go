package main

import "fmt"

const size = 10

func bubblesort(input [size]int64) [size]int64 { // сортировать будем с конца
	for i := size; i > 0; i-- { //бежим с конца цикла
		for j := 1; j < i; j++ { // бежим с начала
			if input[j-1] > input[j] {
				tmpinput := input[j] //перестановка через промежуточный элемент
				input[j] = input[j-1]
				input[j-1] = tmpinput
			}

		}

	}
	return input

}

func main() {
	a := [size]int64{10, 44, 32, 8, 4, 5, 1, 7, 23, 29}
	fmt.Println("---unsorted---")
	fmt.Println(a)

	b := bubblesort(a)
	fmt.Println("---sorted---")
	fmt.Println(b)
}
