package main

import "fmt"

// Напишите функцию, сортирующую массив длины 10 вставками.
func sort(arr []int) []int {
	for i := 1; i < len(arr); i++ {
		j := i

		for j > 0 {
			if arr[j-1] > arr[j] {
				arr[j-1], arr[j] = arr[j], arr[j-1]
			}
			j--
		}
	}

	return arr
}
func main() {
	arr := []int{1, 4, 2, 5, 6, 7, 3, 10, 9}
	fmt.Println(arr)
	fmt.Println("---===sorted===---")
	fmt.Println(sort(arr))

}
