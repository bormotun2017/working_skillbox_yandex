package main

import "fmt"

func main() {
	var sliceExample []int //описываем слайс

	newSliceExample := make([]int, 0, 0) //описание с помощью make , 0,0 длина и емкость
	//первый 0 - колво элементов, 2й 0 - колво элементов которые можно туда поместить
	newStringExample := make([]string, 10, 10)
	fmt.Printf("%+v\n", newStringExample)
	fmt.Printf("%+v\n", sliceExample)
	fmt.Printf("%+v\n", newSliceExample)

}

// атрибуты слайса
//*data массив актуальных данных
//len массив заполненных данных
//cap кол во памяти
