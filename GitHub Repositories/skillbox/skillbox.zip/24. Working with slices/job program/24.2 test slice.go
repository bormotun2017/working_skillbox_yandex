package main

import "fmt"

func debugSlice(input []int) { //функ
	fmt.Printf("data:%+v\n", input)
	fmt.Printf("len:%+v\n", len(input))
	fmt.Printf("cap:%+v\n", cap(input))

}

func main() {
	testSlice := make([]int, 0, 0) // создаем пустой слайс интов
	s := make([]int, 0, 0)
	s = append(s, 1)
	s = append(s, 2)
	debugSlice(s)
	testSlice = append(testSlice, s...) //добавляет в testSlice массив s со всеми его элементами
	debugSlice(testSlice)
	//	testSlice:=make([]int,0,cap(s)) //задает слайс с памятью равной массиву с
	/*	testSlice = append(testSlice, 1) // добавляем в слайс элемент 1
		//append получает на вход. куда добавить, и что добавить. и возвращает уже массив с добавленным элементом
		for i := 0; i < 10; i++ {
			testSlice = append(testSlice, i)
			debugSlice(testSlice)
		}
		debugSlice(testSlice) */

}
