package main

import "fmt"

func debugSlice(input []int) { //функ
	fmt.Printf("data:%+v\n", input)
	fmt.Printf("len:%+v\n", len(input))
	fmt.Printf("cap:%+v\n", cap(input))

}
func main() {
	s := make([]int, 4, 4)
	s[0] = 1
	s[1] = 2
	s[2] = 3
	s[3] = 4
	//debugSlice(s)
	//	for i := 0; i < len(s); i++ { //пробегаем через i
	//		fmt.Println(s[i])
	//	}
	//for i, v := range s { //пробегаем через range, так рекомендуется
	//	fmt.Println(i, v) //i индекс, v значение можно опустить переменную _

	//}
	for i, v := range s {
		s[i] = v * v
	}
	debugSlice(s)

}
