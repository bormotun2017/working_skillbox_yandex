package main

import "fmt"

func debugSlice(input []int) { //функ
	fmt.Printf("data:%+v\n", input)
	fmt.Printf("len:%+v\n", len(input))
	fmt.Printf("cap:%+v\n", cap(input))

}
func remove(slice []int, index int) []int { //для удаления из массива всегда пишут функ
	return append(slice[:index], slice[index+1:]...) //удаляем элемент массива, путем записи нового с пропуском этого элемента
	//capasti при этом не меняется, а длина уменьшается на 1
	//	slice = append(slice[:3], slice[4:]...)станд. функ го по удалению
}
func anotherRemove(slice []int, index int) []int { // удаление переносом элемента
	//более оптимальная функ, выделяет меньше памяти
	slice[len(slice)-1], slice[index] = slice[index], slice[len(slice)-1] // меняем нужный элб с последним эл массива
	return slice[:len(slice)-1]                                           // обрезаем массив по последнему эл
}

func main() {
	s := []int{1, 2, 3, 4, 5, 6}
	debugSlice(s)
	s = remove(s, 2)
	debugSlice(s)

}
