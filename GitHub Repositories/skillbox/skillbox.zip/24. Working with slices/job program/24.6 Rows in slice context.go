package main

import (
	"fmt"
)

func debugSlice(input []byte) { //функ
	fmt.Printf("data:%+v\n", input)
	fmt.Printf("len:%+v\n", len(input))
	fmt.Printf("cap:%+v\n", cap(input))

}
func main() {
	//string <=> byte// строка по сути это массиив байтов(кодов символов)
	exampleString := "empty value"    // создаем строку
	for i, v := range exampleString { //пробегаем строку по эл
		fmt.Println(i, string(v)) //выводим
	}
	debugSlice([]byte(exampleString)) // перевели строку в массив байтов и вызвали функ

}
