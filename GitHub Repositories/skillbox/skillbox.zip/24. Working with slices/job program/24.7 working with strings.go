package main

import (
	"fmt"
	"reflect"
	"strings"
)

func main() {

	a := "first"
	b := "st"
	//compare
	fmt.Println(strings.Compare(a, b)) //функ сравнивает 2 строки на больше меньше или равно, возвр.-1,1,0
	//при чем сравнивает значение байта каждой буквы строки
	fmt.Println([]byte("a"), []byte("f"), []byte("z")) // выведем значения для наглядности
	//index
	index := strings.Index(a, b) //находит индекс первого вхождения b в a, или вернет -1
	if index != -1 {             //если индекс нашелся, то совершаем какие то действия
		//todo
	}
	a = "127.0.0.1"
	c := strings.Split(a, ".") //функ убирает разделитель из строки
	fmt.Println(c)
	fmt.Printf("%+v\n", reflect.TypeOf(c)) //возвращает тип переменной
	for _, v := range c {                  //работаем с как со строкой
		fmt.Println(v)

	}

}
