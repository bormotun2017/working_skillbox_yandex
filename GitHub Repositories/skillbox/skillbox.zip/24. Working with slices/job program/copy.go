package main

import "fmt"

func debugSlice(input []int) { //функ
	fmt.Printf("data:%+v\n", input)
	fmt.Printf("len:%+v\n", len(input))
	fmt.Printf("cap:%+v\n", cap(input))

}
func main() {
	s := []int{1, 2, 3, 4, 5, 6}
	debugSlice(s)
	//	d := s[1:4] // диапазон индексов 1...3 capaciti =5, т.к. считается cap исходного массива
	// - первый индекс. cap[d]=cap[s]-1
	//	debugSlice(d)
	//	e := s[3:5]
	//	debugSlice(e)
	//	e[0] = 10 // заменили в исходном массиве 4 на 10, т.к. e это просто выборка из основного массива
	//и меняя что то в нем, меняется исходный массив
	//	fmt.Println("s", s)
	/////копирование
	d := make([]int, 2, 2) //создаем слайс на 2 эл, вместимостью 2
	copy(d, s[2:4])        //копируем 2,3 эл. массива s в d
	d[0] = 10              // это не изменит эл. массива s. т.к. d самостоятельный слайс
	fmt.Println("s", s)
	fmt.Println("d", d)

}
