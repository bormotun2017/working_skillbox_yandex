package main

import (
	"flag"
	"fmt"
	"log"
)

// Написать программу для нахождения подстроки в кириллической подстроке.
// Программа должна запускаться с помощью команды:
// go run main.go --str "строка для поиска" --substr "поиска"
// Для реализации такой работы с флагами воспользуйтесь пакетом flags
// а для поиска подстроки в строке вам понадобятся руны.
func findSubstrInStr(str *string, substr *string) bool {
	if *str == "" || *substr == "" { // проверка строк на пустоту
		err := fmt.Errorf("nil pointer")

		log.Fatalln(err)
	}
	strRune := []rune(*str)
	subStrRune := []rune(*substr)
	j := 0
	for i := 0; i < len(strRune); i++ { //смотрим массив строки
		if strRune[i] == subStrRune[j] { // если символ строки равен символу подстроки
			j++                       // увеличиваем счетчик
			if j == len(subStrRune) { //если счетчик равен длинне подстроки
				return true // возвращаем true
			}

		} else { //иначе обнуляем счетчик
			j = 0
		}
	}
	return false

}
func main() {
	var str string
	var subStr string
	flag.StringVar(&str, "str", "", "set str")
	flag.StringVar(&subStr, "subStr", "", "set subStr")
	flag.Parse()

	fmt.Println("строка: ", str, " субстрока: ", subStr, findSubstrInStr(&str, &subStr))

}
