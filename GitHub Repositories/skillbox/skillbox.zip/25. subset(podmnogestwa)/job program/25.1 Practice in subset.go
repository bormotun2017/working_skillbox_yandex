package main

import "fmt"

func main() {
	students := []string{"Alice", "Meadow", "Natalie", "Peter", "John", "Tony"}
	studentsSubSlice := students[3:] //выделяем подмножество парней с 4го до конца
	fmt.Println(students)
	fmt.Println(studentsSubSlice)

	studentsSubSlice[0] = "David" // меняем имя
	fmt.Println(students)         // оно меняется везде
	fmt.Println(studentsSubSlice)

	modifySlice(studentsSubSlice) //меняем имя через функ
	fmt.Println(students)         // оно меняется везде
	fmt.Println(studentsSubSlice)

}
func modifySlice(slice []string) {
	slice[0] = "Вася"

}
