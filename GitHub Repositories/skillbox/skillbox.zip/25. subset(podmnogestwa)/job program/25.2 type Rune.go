package main

import (
	"fmt"
	"unicode/utf8"
)

const nihongo = "привет"

func main() {
	character := 'ф'
	fmt.Println(character)                  // 1092
	fmt.Println(string(character))          //ф
	for index, runeValue := range nihongo { //итерация по руне
		fmt.Printf("%#U начинается в позиции %d\n", runeValue, index) //получаем код и символ

	}
	str := "привет"
	for i := 0; i < len(str); i++ {
		fmt.Println(str[i]) //получаем коды
	}
	fmt.Println(string([]rune(str))) //получаем символы
	fmt.Println("=====================")
	strRune := []rune(str)
	for i := 0; i < len(strRune); i++ {
		fmt.Println(strRune[i]) //получаем коды посимвольно
	}
	fmt.Println("==================")
	for _, r := range strRune {
		fmt.Println(r, string(r)) //получаем коды посимвольно и символы
	}

	fmt.Println("====================")
	b := []byte("hello, 﨎﨔﨨")
	for len(b) > 0 {
		r, size := utf8.DecodeLastRune(b) //возвращает руну и размер руны
		fmt.Printf("%c,%v\n", r, size)    //выводим
		b = b[:len(b)-size]               //усекаем массив на размер данной руны
	}

	fmt.Println("====================")
	b = []byte("hello, 﨎﨔﨨")
	for len(b) > 0 {
		r, size := utf8.DecodeLastRune(b) //возвращает руну и размер руны
		fmt.Printf("%c,%v\n", r, size)    //выводим
		b = b[size:]                      //усекаем массив на размер данной руны
	}
}
