package main

import "fmt"

// шифр Цезаря
func main() {
	message := "sometesxt"
	for i := 0; i < len(message); i++ {
		c := message[i]
		for c >= 'a' && c <= 'z' {
			c = c + 13
			if c > 'z' {
				c = c - 26
			}
			fmt.Printf("%+c", c)

		}
	}
}
