package main

import "fmt"

func main() {
	integer := 10
	fmt.Println(integer)                  //10
	integerPointer := &integer            //указатель на integer
	fmt.Println(integerPointer)           //0xc00001c098 адрес в памяти
	integerFromPointer := *integerPointer //разименование указателя, по сути это уже integer
	fmt.Println(integerFromPointer)       //10
	integerFromPointer = 8                // меняем разименованный указатель, меняется исходная переменная
	*integerPointer = 8                   // либо так
	fmt.Println(integer)
	/////////////////////////
	v := 0
	fmt.Println(v)           //0
	changeValueByPointer(&v) //передаем указатель
	fmt.Println(v)           //10 //функ работает с переменной
	v = 0
	changeValueByValue(v)
	fmt.Println(v) //0  не меняем саму переменную
	/////////////////////////////////////////
	a := 4
	aPtr := returnIntByPointer(a)
	fmt.Println(aPtr)  //0xc000014090
	fmt.Println(*aPtr) //4 возвращаем с расшифровкой указателя

}
func changeValueByValue(v int) {
	v = 10
}
func changeValueByPointer(v *int) {
	*v = 10

}
func returnIntByPointer(a int) *int {
	v := a
	return &v
}
