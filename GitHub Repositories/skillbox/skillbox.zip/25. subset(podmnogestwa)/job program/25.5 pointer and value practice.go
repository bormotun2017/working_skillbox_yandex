package main

import (
	"flag"
	"fmt"
	"log"
	"strconv"
)

func main() {
	var name string
	var age int
	flag.IntVar(&age, "age", 0, "set age") // функ позволяют перед запуском программы передать в них
	//переменные
	flag.StringVar(&name, "name", "default name", "set name") // тоже самое для name
	flag.Parse()                                              //парсит(записывает в наши переменные) то что мы в них передали перед запуском
	fmt.Println(name, age)
	printByPointer(&name, &age) // вызываем функ и передаем в нее указатели
	err := printByPointer(nil, nil)
	if err != nil { //проверяем ошибку
		log.Fatalln(err) // печатаем лог фатал
	}

}
func printByPointer(n *string, a *int) error { //передаем в функ указатели
	if n == nil && a == nil { //проверяем на пустоту
		return fmt.Errorf("nil pointer")
	}
	fmt.Println("hello my name is " + *n + " and age is " + strconv.Itoa(*a)) //печатаем
	return nil

}
