package main

import (
	"fmt"
	"io"
	"io/ioutil"
	"os"
)

//Программа должна получать на вход имена двух файлов, необходимо  конкатенировать их содержимое, используя strings.Join.
//При получении одного файла на входе программа должна печатать его содержимое на экран.
//При получении двух файлов на входе программа соединяет их и печатает содержимое обоих файлов на экран.
//Если программа запущена командой go run firstFile.txt secondFile.txt resultFile.txt, то она должна написать два соединённых файла в результирующий.

func main() {
	var fileA, fileB, joinfile string
	switch len(os.Args) {
	case 2: //если передаем один аргумент перед запуском
		fileA = os.Args[1]   //имя файла равно первому аргументу
		a := readFile(fileA) //вызываем функб печатаем файл
		fmt.Printf("%s \n", a)
	case 3:
		fileA = os.Args[1]            //файл а равен первому аргументу
		fileB = os.Args[2]            //файл б равен второму аргументу
		joinfile = join(fileA, fileB) //вызываем функ сложения
		fmt.Printf("%s \n", joinfile) //печатаем
	case 4:
		fileA = os.Args[1]            //файл а равен первому аргументу
		fileB = os.Args[2]            //файл б равен второму аргументу
		joinfile = join(fileA, fileB) //вызываем функ сложения
		fileResult := "resultFile.txt"
		_, err := os.Stat(fileResult) // получаем информацию о файле
		if err != nil {

			if os.IsNotExist(err) { //проверка на существование файла
				file, err := os.Create(fileResult) // создание файла
				if err != nil {                    // обработка ошибки
					fmt.Println("Не смогли создать файл", err)
					return
				}

				defer file.Close() // отложенное закрытие файла
			}
		}
		if err := ioutil.WriteFile(fileResult, []byte(joinfile), 0666); err != nil { // переводим нашу строку в
			// массив байт и пишем его в файл
			fmt.Println(err)
		}
		fmt.Printf("мы записали в resultFile.txt %s \n", joinfile)
	default:
		fmt.Println("программу необходимо запустить с аргументами из командной строки")

	}

}
func join(fileA, FileB string) (join string) { //
	fileOne := readFile(fileA)       //вызываем в нашу функ массив байт первого файла
	fileTwo := readFile(FileB)       // вызываем в нашу функ массив байт второго файла
	fileOneString := string(fileOne) // переводим массивы байт в строки
	fileTwoString := string(fileTwo)
	join = fileOneString + " " + fileTwoString //складываем содержимое
	return join
}

func readFile(fileName string) []byte {
	info, err := os.Stat(fileName) // получаем информацию о файле
	if err != nil {

		if os.IsNotExist(err) { //проверка на существование файла
			fmt.Println("файл не существует")
		}
	}
	file, err := os.Open(fileName) // открываем файл
	if err != nil {
		fmt.Println("err")
	}
	defer file.Close()                              // отложенное закрытие файла
	b := make([]byte, info.Size())                  // создание переменной равной размеру файла
	if _, err := io.ReadFull(file, b); err != nil { // читаем файл в буфер
		panic(err)
	}
	//fmt.Println("====================")
	//fmt.Printf("%s \n", b) // выводим буфер
	return b //возвращаем массив байт

}
