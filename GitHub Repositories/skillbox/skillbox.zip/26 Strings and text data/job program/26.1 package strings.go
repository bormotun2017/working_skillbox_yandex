package main

import (
	"fmt"
	"strings"
)

func main() {
	str := "Some Strings"
	strInLowerCase := strings.ToLower(str) //переводим в нижний регистр
	fmt.Println(strInLowerCase)
	strInUpperCase := strings.ToUpper(str) //переводим в верхний регистр
	fmt.Println(strInUpperCase)
	haveSome := strings.HasPrefix(str, "Some") //ищет вхождение с начала
	fmt.Println(haveSome)                      //true
	haveIng := strings.HasSuffix(str, "ing")   //ищет вхождение с конца
	fmt.Println(haveIng)                       //true
	haveSt := strings.Contains(str, "St")      //ищет вхождение везде
	fmt.Println(haveSt)                        //true
	haveS := strings.Count(str, "S")           // ищет количество вхождений
	fmt.Println(haveS)                         //2
	str = "string"
	fmt.Println(len(str)) //6 //английский идет в ascii кодировке 1 буква 1 байт
	str = "строка"
	fmt.Println(len(str))         //22 кирилица идет в utf8
	fmt.Println(len([]rune(str))) // 6 привели к массиву рун
}
