package main

import (
	"fmt"
	"strings"
)

func main() {
	//strings.Split()
	fmt.Printf("%q\n", strings.Split("1,2,3", ",")) //делит строку на отрезки по разделителю и возвращает
	//обрезанные элементы
	//["1""2""3"]
	fmt.Printf("%q\n", strings.Split("a table, a dog, a chair", "a "))
	//["" "table, " "dog, " "chair"]
	fmt.Printf("%q\n", strings.Split("rune slice", ""))
	//["r"u"n"e""""s"l"i"c"e"]
	fmt.Printf("%q\n", strings.Split("", "empty string"))
	//[""]
	str := "a, b, c, d"
	fmt.Println(strings.Split(str, " "))

	//SplitAfter
	strSplittedAfter := strings.SplitAfter(str, ",")
	fmt.Println(strSplittedAfter) // в отличие от split вернула с пробелом

	strSplitAfterN := strings.SplitAfterN(str, ",", 2) //возвращает n вхождений
	for _, str := range strSplitAfterN {
		fmt.Printf("%s \t", str)
		//a,   b,c,d 2 вернули 2 строки
	}
	fmt.Println()

	strSplitAfterN = strings.SplitAfterN(str, ",", 0) // возвращает nil
	for _, str := range strSplitAfterN {
		fmt.Printf("%s \t", str)
		// пустая
	}
	fmt.Println()

	strSplitAfterN = strings.SplitAfterN(str, ",", -1) // возвращает все подстроки
	for _, str := range strSplitAfterN {
		fmt.Printf("%s \t", str)
		///a,    b,   c,  d вернули 4 строки
	}
	fmt.Println()

	// splitN

	strSplitN := strings.SplitN(str, ", ", 2) //работает так же как splitaftern
	//но берет сам разделитель
	fmt.Println(strSplitN) // [a b, c, d] 1я строка a 2я b,c,d
	strSplitN = strings.SplitN(str, ", ", 0)
	fmt.Println(strSplitN) //[]
	strSplitN = strings.SplitN(str, ", ", -1)
	fmt.Println(strSplitN) //[a b c d]

}
