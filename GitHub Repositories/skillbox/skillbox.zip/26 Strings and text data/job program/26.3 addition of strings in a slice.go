package main

import (
	"fmt"
	"strings"
)

//соединяем строки в массив

func main() {
	//соединяем вручную
	strSlice := []string{"some", "very", "long", "string"}
	strResult := ""
	for idx, str := range strSlice { //str равно каждому эл массива по отдельности
		if idx == len(strSlice) { //если строка последняя в слайсе
			strResult += str //добавляем без пробела и выходим из цикла
			break
		}
		strResult += str + " " // добавляем в строку эл массива + пробел

	}
	fmt.Println(strResult)

	//strings.Join

	resStr := strings.Join(strSlice, " ") // объединяет строки по разделителю
	fmt.Println(resStr)

}
