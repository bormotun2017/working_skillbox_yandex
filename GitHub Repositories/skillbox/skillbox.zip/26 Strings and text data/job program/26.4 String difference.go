package main

import (
	"fmt"
	"strings"
)

func main() {
	fmt.Println("a" < "b")   //true
	fmt.Println("a" == "a")  //true
	fmt.Println("a" != "b")  //true
	fmt.Println("a" > "b")   //false
	fmt.Println("ab" > "ac") //false
	fmt.Println("ab" < "ac") //true
	fmt.Println("=================")
	str1 := "aaa"
	str2 := "bbb"
	str1Equal := "aaa"

	compareRes := strings.Compare(str1, str2) // -1 если a<b
	fmt.Println(compareRes)
	compareRes = strings.Compare(str2, str1) //1 0 если a>b
	fmt.Println(compareRes)
	compareRes = strings.Compare(str1Equal, str1) //0 если a=b
	fmt.Println(compareRes)
	fmt.Println("==============")

	//index

	str := "Hello world"            //asci строка
	idx := strings.Index(str, "el") // возвращает индекс первого вхождения
	fmt.Println(idx)                //1

	str = "Привет Мир!" //utf8 строка
	idx = strings.Index(str, "ри")
	fmt.Println(idx) // 2, что не верно, надо разбирай на руны

}
