package main

//Напишите программу, которая считывает ввод с stdin, создаёт структуру student
// и записывает указатель на структуру в хранилище map[studentName] *Student.
// type Student struct {
// name string
// age int
// grade int
// Программа должна получать строки в бесконечном цикле, создать структуру Student через функцию newStudent,
// далее сохранить указатель на эту структуру в map, а после получения EOF (ctrl + d)
// вывести на экран имена всех студентов из хранилища. Также необходимо реализовать методы put, get.

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"strconv"
	"strings"
)

type Student struct {
	name  string
	age   int
	grade int
}

func Put(name string, age int, grade int) *Student {
	return &Student{name, age, grade}
}

func Print(s Student) {
	fmt.Println(s.name, s.age, s.grade)
}
func main() {
	fmt.Println("Введите имя студента возраст и курс через пробел")
	fmt.Println("Для завершения введите комбинацию клавишь Ctrl+D")

	mapStudent := make(map[string]*Student, 0)
	var in = bufio.NewReader(os.Stdin)

	for {
		str, err := in.ReadString('\n')

		if err == io.EOF {
			break
		}
		addNewStudent(mapStudent, str)
	}

	printStudent(mapStudent)
}

func addNewStudent(mapStudent map[string]*Student, str string) {
	name, age, grade := getContent(str)
	mapStudent[name] = Put(name, age, grade)
}

func getContent(str string) (name string, age int, grade int) {
	parseStr := strings.Fields(str)

	name = parseStr[0]
	age, _ = strconv.Atoi(parseStr[1])
	grade, _ = strconv.Atoi(parseStr[2])

	return
}

func printStudent(mapStudent map[string]*Student) {
	fmt.Println()
	fmt.Println("Студенты из хранилища:")
	for _, v := range mapStudent {
		Print(*v)
	}
}
