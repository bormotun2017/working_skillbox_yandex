package main

import "fmt"

func main() {
	//map(карта) - ассоциативный массив который может отображать разные типы данных в зависимости от ключа
	//map[key type] value type
	//map[int] string например массив интов может отображаться в строке
	m := make(map[int]string) //инициализация через make, ключевое слово map
	fmt.Println(m)
	m[1] = "first" //обращение к элементу по индексу
	m[2] = "second"
	fmt.Println(m)    //map[1:first 2:second] выводит целиком
	fmt.Println(m[2]) //second //выводит значение по индексу
	fmt.Println("------------------")
	//delete
	delete(m, 2)   //функ удаления ключа
	fmt.Println(m) //map[1:first]
	fmt.Println("------------------")

	mString := make(map[string]float64)
	mString["first"] = 1.0
	mString["second"] = 2.0
	fmt.Println(mString) //map[first:1 second:2]
	fmt.Println("------------------")

	//композитный литерал
	mString = map[string]float64{ //еще один способ описания мапы
		"third": 3.0,
		"forth": 4.0,
	}
	fmt.Println(mString)
	fmt.Println("------------------")

	//
	//	var mNil map[int]string //так нельзя потому что нету make
	//var mNil make(map[int]string) если сделать так то будет работать
	//	mNil[1] = "first"
	//	fmt.Println(mNil) //panic: assignment to entry in nil map
	//	fmt.Println("------------------")

	//
	mLen := map[int]string{
		1: "first",
		2: "second",
		3: "third",
	}
	fmt.Println(len(mLen)) //3 длина массива
	fmt.Println("---------------------")
	fmt.Println(mLen[4]) //обращаемся по несуществующему индексу, выводит ""
	v, ok := mLen[4]
	fmt.Println(v, ok) //nil,false false говорит, что такого ключа в мапе нет
	//проверка есть ли такое значение в мапе
	_, ok = mLen[4]
	fmt.Println(ok) //false
	_, ok = mLen[3]
	fmt.Println(ok) //true

}
