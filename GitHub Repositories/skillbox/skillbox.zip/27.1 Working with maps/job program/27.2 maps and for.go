package main

import (
	"fmt"
	"sort"
)

func main() {
	m := map[int]string{
		1: "first",
		2: "second",
		3: "third",
		4: "forth",
	}
	//	for k := range m { //выводит ключи в произвольном порядке
	//		fmt.Println(k)
	//	}

	//for v, k := range m { //тоже самое
	//	fmt.Println(v, k)
	//}
	// как читать мапу по порядку
	keySlice := make([]int, 0) //создаем пустой слайс
	for k := range m {
		keySlice = append(keySlice, k) //записываем в него все ключи нашей мапы
	}
	fmt.Println()
	fmt.Println(keySlice)

	sort.Ints(keySlice) //сортируем слайс
	//sortedKeys := sort.Ints //сортируем слайс

	fmt.Println(keySlice)

	for _, key := range keySlice { //итерируемся по сортированному слайсу
		fmt.Println(m[key]) //выводим значения
	}
}
