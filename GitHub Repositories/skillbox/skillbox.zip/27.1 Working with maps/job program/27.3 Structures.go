package main

import "fmt"

// структуры - пользовательский тип данных, который разработчик определяет сам
// содержат различные поля данных,мэпы, указатели на разлиыне типы и другие структуры
type Person struct { //описание структуры
	age  int //поля структуры
	name string
}

func main() {
	p := Person{ //описывам переменную с типом нашей структуры
		age:  21, //заполянем поля
		name: "Peter",
	}
	fmt.Println(p) // {21 Peter}
	fmt.Println("-----------")

	p = Person{40, "John"} //можно так
	fmt.Println(p)         // {40 John}
	fmt.Println("-----------")

	pZeroValue := Person{}  //можно так
	fmt.Println(pZeroValue) //{0,""} //
	fmt.Println("-----------")

	pPointer := &p //указатель на p
	fmt.Println(pPointer)
	fmt.Println("-----------")

	student := &Person{24, "Anthony"} //создаем указатель на структуру
	fmt.Println(student)
	fmt.Println("-----------")

	fmt.Println(student.age) //обращение к полям структуры
	fmt.Println(student.name)

	student.name = "lili" //перезапись полей структуры
	fmt.Println(student)  // &{24 liLl}

	pPrt := new(Person) // создаем указатель без & амперсанты
	fmt.Println(pPrt)   // но тогда она будет пустой
}
