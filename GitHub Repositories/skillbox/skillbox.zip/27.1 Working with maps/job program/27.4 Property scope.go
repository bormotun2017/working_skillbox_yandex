package main

import (
	"fmt"
	"job_program/person" //импортируем структуру из другого модуля
)

func main() {
	p := person.Person{ //ссылаемся на структуру из другого модуля
		Name: "Tony Soprano",
		Age:  40,
		//sibiling: "AJ" // не видит данное поле, т.к. оно в пакете было заполнено с маленькой буквы
		Sibiling: "AJ",
	}
	fmt.Println(p)
	fmt.Println(person.PrintInfo(p)) //вызываем функ из другого пакета но не можем вызвать с маленькой буквы
	//fmt.Println(person.printInfo(p))///так не увидит
	//
	fmt.Println(person.C) //выводим константу с модуля person. c маленькой буквы не увидит
	//можно там написать функ вывода конст с маленькой буквы и вызвать здесь, тогда получится

}
