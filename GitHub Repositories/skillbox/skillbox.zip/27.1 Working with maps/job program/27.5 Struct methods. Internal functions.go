package main

import (
	"fmt"
	"job_program/person1"
	"reflect"
	"strconv"
)

type MyInt int //обявляем новый тип

func (mi MyInt) toString() string { // объявляем метод, который делает из int string
	return strconv.Itoa(int(mi)) //возвращаем конвертацию из int v string
}

func main() {

	p := person1.Person{
		Age:  30,
		Name: "Corado",
	}
	//PrintInfo(p)
	p.SetNameByValue("Tony")
	fmt.Println(p) //{Corado}//Имя не изменилось, т.к. работали с копией пекременной
	p.SetNameByPointer("Tony")
	fmt.Println(p) //{Tony} Имя изменилось, т.к. работали с указателем
	//	p.Print() //обращаемся к функ через переменную
	//Print() так нельзя
	////
	var i MyInt = 10                        // задаем переменную
	iStr := i.toString()                    //задаем переменную с результатом
	fmt.Println(iStr, reflect.TypeOf(iStr)) // выводим переменную и ее тип
	//fmt.Printf(iStr, "%T", iStr)
	c

}
