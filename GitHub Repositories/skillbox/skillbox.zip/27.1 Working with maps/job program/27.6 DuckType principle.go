package main

import "fmt"

// если тип соответствует данному интерфейсу, то он принадлежит к данному интерфейсу и умеет делать
// все из данного интерфейса
// DuckType если крякает как утка, то это утка
type IWorker interface { //объявляем интерфейс IWorker
	work() //метод интерфейса
}

type IPerson interface { //интерфейс будет печаать содержимое структуры
	Printer()
}

type Person struct {
	Name string
	Age  int
	w    IWorker //делаем поле w с типом интерфейса IWorker
}

func (w Person) work() {
	fmt.Println(w)
}

func (p Person) Printer() { // функи вызывает функ Printer? неопнятно нахуя такие сложности
	fmt.Println(p)

}

type IBarker interface { //объявление интерфейса
	Bark() string
}
type DogName string

func (dn DogName) Bark() string { //функция собака
	return string(dn) + ": aw aw aw" //она лает
}
func PrintBark(i IBarker) { //передаем интерфейс в функ
	fmt.Println(i)
}
func PrintType(i interface{}) { //принимает пустой интерфейс и печатает его
	switch i.(type) { // смотрит тип преданного фргумента и печатает его
	case string:
		fmt.Println("string")
	case int:
		fmt.Println("int")

	}

}

func main() {
	//	var empty interface{} = Person{} //объявляем пустой интерфейс, он соответсвует любому типу или структуре
	PrintType(1)             //int
	PrintType("123")         //string
	dn := DogName("whisper") //вызываем метод
	fmt.Println(dn.Bark())   //whisper: aw aw aw

	PrintBark(dn) //whisper

	p := Person{
		Name: "John",
		Age:  20,
	}

	var iPrinter IPerson = p //создаем переменную iPrinter и передаем в нее переменную p
	iPrinter.Printer()       //вызываем метод Printer через переменную iPrinter, в которую передали переменную p
	/// блять такое масло масляное просто пиздец....

	p.work() //{John 20 <nil>}

}
