package main

import (
	"fmt"
)

func (c person) info(a int) int { // метод для переменной типа person. принимает дополнительно инт число
	fmt.Println(c) // печатает структуру
	a = a + 10
	return a //возвращает число
}
func (c *person) rename() { //метод переименования поля name
	c.name = "Tony" //имя
	fmt.Println(*c) // разименовываем указатель иначе выведет &{12 Tony}
}

type person struct {
	age  int
	name string
}

func main() {

	p := person{
		age:  12,
		name: "Alex",
	}
	p.info(10)
	fmt.Println(p.info(10))
	p.rename()     //вызвали метод
	fmt.Println(p) //поменяли имя
}
