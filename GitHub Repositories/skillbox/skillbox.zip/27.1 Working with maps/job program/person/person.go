package person

import "strconv"

const C = "from person package"

type Person struct { // описываем структуру в другом модуле
	Age      int // все поля с большой буквы импортируются в другие пакеты и к ним можно обращаться
	Name     string
	Sibiling string // c маленькой буквы локальные поля внутри этого пакета
	//с функциями тоже самое, если она начинается с маленькой буквы, она не экспортируется, если с большой то экспортируется
}

// пишем функ вывода структуры которая экспортируется в другой пакет
func PrintInfo(p Person) string { //пишем с большой, чтобы вызвать в другом пакете
	return info(p)
}

func info(p Person) string { //пишем с маленькой буквы, чтобы была видна только внутри нашей программы
	return "My name is " + p.Name + "and age is " + strconv.Itoa(p.Age) + " and my son is " + p.Sibiling
}
