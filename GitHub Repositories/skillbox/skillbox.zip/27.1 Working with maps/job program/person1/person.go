package person1

import "fmt"

type Person struct {
	Age  int
	Name string
}

func PrintInfo(p Person) { // принимает переменную типа Person
	fmt.Println(p) //печатает
}

//func (p Person) Info() {
//	fmt.Println(p)
//}

// МЕТОД
func (p Person) SetNameByValue(n string) { // объявление метода. пепед функ пишется ресивер
	p.Name = n //работаем с копией переменной из main
}
func (p *Person) SetNameByPointer(n string) { //работаем с указателем
	p.Name = n

}
