package main

import (
	"fmt"
	//сначала пишем в терминале go get, он ее скачивает и устанавливает
	sl "github.com/vpatsenko/skilllog" //импортируем библиоткеку с гита

	"log"
)

func main() {
	l, err := sl.NewLogger("log.txt")
	if err != nil {
		log.Fatalln(err)
	}
	fmt.Println(l)
	l.Info("some info log") //вызываем методы логгера
	l.Error(fmt.Errorf("some error"))
	if err := l.Close(); err != nil {
		log.Fatalln(err)
	}

}
