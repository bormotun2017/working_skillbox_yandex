package main

import (
	"go.uber.org/zap"
	"log"
)

func main() {
	l, err := zap.NewProduction()
	if err != nil {
		log.Fatalln(err)
	}
	defer func() { //отложенный вызов функ sync, чтобы записать логгре в файл
		l.Sync()
	}()
	l.Info("some info")
	l.Error("some err", zap.String("key", "value"))
	//go get -u go.uber.org/zap обновили наш логгер
	//go mod tidy - чистит несуществующие зависимости в проекте
}
