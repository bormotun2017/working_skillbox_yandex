package main

import (
	"fmt"
	"job_program/pkg/post"
	"job_program/pkg/repo/post_repo"
	"job_program/pkg/repo/user"
	"job_program/pkg/repo/user_repo"
)

func main() {
	us := user_repo.NewUserStorage() //инициализировали хранилища
	ps := post_repo.NewPostStorage()
	tony := user.NewUser("Anthony") //создали пользователей
	jhonny := user.NewUser("Jhony Sack")
	tony.MakeFriend(jhonny)                           //подружили
	p := post.NewPost(tony.Name, "some post content") //создали пост
	ps.Put(p)                                         //сохранили в хранилище
	us.Put(tony)
	us.Put(jhonny)
	for _, users := range us {
		fmt.Println(users)
	}
	for _, posts := range ps {
		fmt.Println(posts)
	}

}
