package post

type Post struct { //тип пост
	Author  string
	Content string
}

func NewPost(author, content string) *Post { //принимаем поляб возвращаем указатель на структуру Post
	return &Post{
		Author:  author,
		Content: content,
	}

}
