package post_repo

import (
	"fmt"
	"job_program/pkg/post"
)

//пишем тоже самое для Post

type PostStorage map[string]*post.Post //создаем тип хранилище для структуры User с указателем
// чтобы работать непосредственно с самой структурой User

func NewPostStorage() PostStorage { //функ создает массив со структурой User b возвращает
	//UserStorage
	return make(map[string]*post.Post)

}
func (ps PostStorage) Put(p *post.Post) { //метод put записывает нашу запись в хранилище
	ps[p.Author] = p
}
func (ps PostStorage) Get(authorName string) (*post.Post, error) { //метод get возвращает полоьзователя из хранилища
	//если он есть, если нет, выдает ошибку
	u, ok := ps[authorName]
	if !ok { //если ok нет, то возвращаем nil и сообщение об ошибке
		return nil, fmt.Errorf("no such user")
	}
	return u, nil // иначе возвращаем username и nil
}
