package user

import "job_program/pkg/post"

type User struct { //создаем структуру User
	Name    string
	Posts   []*post.Post //поле массив со ссылкой на тип Post
	Friends []*User      //ссылка на тип User
}

func NewUser(name string) *User { //передаем имя, возвращаем указатель на структуру
	//т.е. совершаем операции непосредственно со структурой User
	return &User{ //возвращаем указатель
		Name:    name,
		Posts:   make([]*post.Post, 0), // создаем массив для постов
		Friends: make([]*User, 0),      // создаем массив для друзей
	}
}

func (u *User) MakeFriend(userFriend *User) { //создаем метод для структуры User
	//принимаем указатель, возвращаем тоже. метод создает друзей
	u.Friends = append(u.Friends, userFriend) //добавляем
}
func (u *User) AddPost(p *post.Post) { //создаем метод для структуры User
	//метод добавляет посты
	u.Posts = append(u.Posts, p)

}
