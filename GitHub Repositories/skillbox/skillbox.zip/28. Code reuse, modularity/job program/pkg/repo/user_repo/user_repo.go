package user_repo

import (
	"fmt"
	"job_program/pkg/repo/user"
)

type UserStorage map[string]*user.User //создаем тип хранилище для структуры User с указателем
// чтобы работать непосредственно с самой структурой User

func NewUserStorage() UserStorage { //функ создает массив со структурой User b возвращает
	//UserStorage
	return make(map[string]*user.User)

}
func (us UserStorage) Put(u *user.User) { //метод put записывает нашу запись в хранилище
	us[u.Name] = u
}
func (us UserStorage) Get(userName string) (*user.User, error) { //метод get возвращает полоьзователя из хранилища
	//если он есть, если нет, выдает ошибку
	u, ok := us[userName]
	if !ok { //если ok нет, то возвращаем nil и сообщение об ошибке
		return nil, fmt.Errorf("no such user")
	}
	return u, nil // иначе возвращаем username и nil
}
