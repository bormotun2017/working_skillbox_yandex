package main

import (
	"fmt"
	"os"
	"os/signal"
	"sync"
	"time"
)

//Напишите приложение, которое выводит квадраты натуральных чисел на экран,
//а после получения сигнала ^С обрабатывает этот сигнал, пишет «выхожу из программы» и выходит.

func main() {
	var i int
	done := make(chan os.Signal, 1) // создаем буф канал на 1 значение
	//os.signal складывает в канал наш ввод
	signal.Notify(done, os.Interrupt) // notify будет отлавливать сигнал
	//os. interrupt - это тип сигнала в нашем случа ^C
	var wg sync.WaitGroup //создаем выйт группу
	wg.Add(1)
	go func() { // создаем анонимную горутину
		defer wg.Done() //отоженное выполнение wg группы
		for {
			select { //
			case <-done: // если мы волучили в канал нашу команду ^C
				fmt.Println("exit")
				return
			default: //если мы получили в канал любое другое значение
				i++
				fmt.Println(i * i)      //выводим квадрат числа
				time.Sleep(time.Second) //спим секунду

			}

		}
	}()
	wg.Wait()

}
