package main

import (
	"fmt"
	"sync"
)

func main() {
	var wg sync.WaitGroup //создаем переменную для синхронизации горутин
	wg.Add(2)             //указываем сколько горутин мы хотим создать
	go putBook(&wg)       // создаем горутину первой функ и передаем туда указатель для синхронизации
	go deliverBook(&wg)   //создаем горутину второй функ

	wg.Wait() //по сути это счетчик го рутин, когда он доходит до 0 выполняется main и с ним burnbok
	//time.Sleep(time.Millisecond * 6) пробуем спать, чтобы синхронизировать горутины
	burnBook() // на 3ю не будем создавать, т.к. Main тоже го рутина

}
func putBook(wg *sync.WaitGroup) { //функ первый гофер складывает книги
	//time.Sleep(time.Millisecond * 2)
	defer wg.Done() //выполняем го рутину через дефер
	fmt.Println("складываю книги")

}
func deliverBook(wg *sync.WaitGroup) { //функ второй гофер доставляю книги
	//time.Sleep(time.Millisecond * 4)
	defer wg.Done() //выполняем го рутину через дефер
	fmt.Println("доставляю книги")
}
func burnBook() { //функ третий гофер сжигаю книги
	fmt.Println("сжигаю книги")

}
