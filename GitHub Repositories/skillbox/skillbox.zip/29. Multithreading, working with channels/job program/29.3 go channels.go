package main

import (
	"fmt"
)

func main() {
	respChan := make(chan string) //инициализация канала через make. chan ключевое слово

	go putBook(respChan)     // создаем горутину первой функ и передаем туда канал в качестве аргумента
	go deliverBook(respChan) //создаем горутину второй функ

	burnBook() // на 3ю не будем создавать, т.к. Main тоже го рутина

}
func putBook(rchan chan string) { //функ первый гофер складывает книги
	//получаем канал в качестве аргумента
	fmt.Println("складываю книги")

}
func deliverBook(rchan chan string) { //функ второй гофер доставляю книги
	//получаем канал в качестве аргумента
	fmt.Println("доставляю книги")
}
func burnBook() { //функ третий гофер сжигаю книги
	fmt.Println("сжигаю книги")

}
