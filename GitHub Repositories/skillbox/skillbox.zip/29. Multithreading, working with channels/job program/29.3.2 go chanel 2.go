package main

import (
	"fmt"
)

func main() {
	intChan := make(chan int) //создаем канал int

	//go func() {
	//	<-strChan
	//}()
	//strChan <- "" //<- синтаксис записи какого либо значения в канал
	//	close(strChan)       //закрытие канала
	//	str, ok := <-strChan //читаем канал
	//	fmt.Println(str)     // ""
	//	fmt.Println(ok)      // false

	go func() { //функ записи в канал
		for i := 0; i < 4; i++ {
			intChan <- i //посылаем в канал значение i
		}
		close(intChan) //канал всегда закрываем пишущая го рутина
	}()

	//	for { //в бесконечном цикле читаем канал
	//		val, ok := <-intChan
	//		if !ok { //если канал закрыт то выходим. обязательно проверять, иначе будет ошибка
	//			break
	//		}
	//		fmt.Println(val) /// 0,1,2,3
	//	}

	// либо через range

	for val := range intChan { // читаем содержимое канала
		fmt.Println(val)

	}

}
func putBook(rchan chan string) { //функ первый гофер складывает книги
}
func deliverBook(rchan chan string) { //функ второй гофер доставляю книги
}
func burnBook() { //функ третий гофер сжигаю книги
	fmt.Println("сжигаю книги")
}
