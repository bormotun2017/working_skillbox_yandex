package main

import "fmt"

func main() {
	bufChan := make(chan int, 3) //создаем буферезированный канал на 3 значения
	bufChan <- 1                 //отправляем в канал значения
	bufChan <- 1
	fmt.Println(len(bufChan), cap(bufChan)) // 2 и 3.  len и cap как массивах. cap - размер буфера
	// равен 3. len - заполненность на текущий момент - 2
	close(bufChan) //закрыли канал
	// /небуферизированные каналы
	//	fc := putBook()
	//	sc := deliverBook(fc) //передаем первый канал во вторую функ
	//	tc := burnBook(sc)    //передаем второй канал в 3ю
	//	fmt.Println(<-tc)     //выводим значение 3го канала
	//	defer close(tc)       //закрываем 3й канал

}

func putBook() chan string { //функ первый гофер складывает книги
	//ничё не принимает , возвращает канал
	firstChan := make(chan string) //создаем канал стрингов
	go func() {
		firstChan <- "собираю книги в тележку" // пишем в канал строку
	}() //создаем го рутину

	return firstChan //возвращаем канал
}
func deliverBook(firstChan chan string) chan string { //функ второй гофер доставляю книги
	secondChan := make(chan string) //опять создаем канал
	fmt.Println(<-firstChan)        //выводим сообщение из первого канала
	close(firstChan)                //закрываем канал
	go func() {                     //создаем го рутину
		secondChan <- "Везу тележку"
	}()
	return secondChan //возвращаем второй канал

}
func burnBook(secondChan chan string) chan string { //функ третий гофер сжигаю книги
	thirdChan := make(chan string) //опять создаем канал
	fmt.Println(<-secondChan)      //выводим сообщение из первого канала
	close(secondChan)              //закрываем второй канал
	go func() {                    //создаем го рутину
		thirdChan <- "Сжигаю книги"
	}()
	return thirdChan //возвращаем второй канал

}
