package main

import "fmt"

func main() {
	var username string
	var password string
	fmt.Println("Здравствуйте, это программа для входа пользователя")
	fmt.Print("Введите логин:")
	fmt.Scan(&username)
	fmt.Println("Введите пароль:")
	fmt.Scan(&password)
	fmt.Println("-----")
	fmt.Print(username, ", вы успешно зашли!")
}
