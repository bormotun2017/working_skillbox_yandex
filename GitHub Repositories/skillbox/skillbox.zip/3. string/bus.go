package main

import "fmt"

func main() {
	var stantion1 = "ул. Будапештская"
	var stantion2 = "ул. Славы 4"
	var stantion3 = "Вечный огонь"
	var stantion4 = "Аэропорт"
	var ticketAmount = 20

	var passengersOnBus int
	var totalSum int
	var gotOnBus int
	var gotOffBus int

	/* на первой остановке никого не высаживаем, маршрутка пуста */
	fmt.Println("Прибываем на остановку", stantion1)
	fmt.Println("В салоне пассажиров:", passengersOnBus)
	fmt.Print("Сколько пассажиров зашло на остановке: ")
	fmt.Scan(&gotOnBus)
	totalSum += (gotOnBus * ticketAmount)
	passengersOnBus += gotOnBus
	fmt.Println("Отправляемся с остановки", stantion1)
	fmt.Println()

	fmt.Println("Прибываем на остановку", stantion2)
	fmt.Println("В салоне пассажиров:", passengersOnBus)
	fmt.Print("Сколько пассажиров вышло на остановке: ")
	fmt.Scan(&gotOffBus)
	passengersOnBus -= gotOffBus
	fmt.Print("Сколько пассажиров зашло на остановке: ")
	fmt.Scan(&gotOnBus)
	totalSum += (gotOnBus * ticketAmount)
	passengersOnBus += gotOnBus
	fmt.Println("Отправляемся с остановки", stantion2)
	fmt.Println()

	fmt.Println("Прибываем на остановку", stantion3)
	fmt.Println("В салоне пассажиров:", passengersOnBus)
	fmt.Print("Сколько пассажиров вышло на остановке: ")
	fmt.Scan(&gotOffBus)
	passengersOnBus -= gotOffBus
	fmt.Print("Сколько пассажиров зашло на остановке: ")
	fmt.Scan(&gotOnBus)
	totalSum += (gotOnBus * ticketAmount)
	passengersOnBus += gotOnBus
	fmt.Println("Отправляемся с остановки", stantion3)
	fmt.Println()

	fmt.Println("Прибываем на остановку", stantion4)
	fmt.Println("В салоне пассажиров:", passengersOnBus)
	fmt.Println("Конечная, все пассажиры вышли")
	passengersOnBus = 0
	fmt.Println()

	driverSalary := totalSum / 4
	taxes := totalSum / 5
	carRepair := totalSum / 5
	fuelConsumption := totalSum / 5
	income := totalSum - (driverSalary + taxes + carRepair + fuelConsumption)

	fmt.Println("Всего заработано", totalSum, "руб.")
	fmt.Println("Зарплата водителя:", driverSalary, "руб.")
	fmt.Println("Расходы на топливо:", fuelConsumption, "руб.")
	fmt.Println("Налоги", taxes, "руб.")
	fmt.Println("Расходы на ремонт машины:", carRepair, "руб.")
	fmt.Println("Итого доход:", income, "руб.")
}
