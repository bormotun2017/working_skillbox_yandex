package main

import "fmt"

func main() {
	var startHeight int
	fmt.Println("Бамбук против вредителей")
	fmt.Println("Высота саженца")
	fmt.Scan(&startHeight)

	var growth int
	fmt.Println("Скорость роста")
	fmt.Scan(&growth)

	var losses int
	fmt.Println("Скорость поедания")
	fmt.Scan(&losses)

	var targetDays int
	fmt.Println("Количество дней")
	fmt.Scan(&targetDays)

	currentgrowth := growth*(targetDays-1) + (growth)/2
	currentlosses := losses * (targetDays - 1)
	currentHeight := startHeight + currentgrowth - currentlosses
	fmt.Printf("К середине %v дня бамбук вырастит до %d сантиметоров\n", targetDays, currentHeight)
}
