package main

import "fmt"

func main() {
	var username string
	var password string
	var age int
	fmt.Println("Здравствуйте, это программа для регистрации")
	fmt.Println("Введите Имя пользователя")
	fmt.Scan(&username)
	fmt.Println("Введите пароль")
	fmt.Scan(&password)
	fmt.Println("Введите возраст")
	fmt.Scan(&age)
	fmt.Print("Поздравляю, ", username, " теперь вы зарегистрированы!\n")
	fmt.Println("Ваш пароль:", password)
	fmt.Println("Ваш возраст:", age)
}
