package main

import (
	"bufio"
	"fmt"
	"log"
	"net"
	"strings"
)

func main() {
	//посмотреть порыт каманда netstat -a в cmd
	// открываем соединение
	lis, err := net.Listen("tcp", "localhost:8080") //
	if err != nil {                                 //проверяем ошибку
		log.Fatalln(err)
	}
	fmt.Println("server is running")
	con, err := lis.Accept() //чтобы принимать соединение с этим сокетом нужна эта функ
	if err != nil {          //проверяем ошибку
		log.Fatalln(err)
	}

	for {
		line, err := bufio.NewReader(con).ReadString('\n') //создаем ридер, чтобы читать что вводят
		//line, _, err := reder.ReadLine()               // присваиваем переменным значение введенного ридера
		if err != nil { //проверяем ошибку
			log.Fatalln(err)
		}
		fmt.Println("line : ", string(line))

		upperLine := strings.ToUpper(string(line)) //преобразуем переданную строку в верх регистр
		if _, err := con.Write([]byte(upperLine)); err != nil {
			log.Fatalln(err) //если строка не равна nil то записываем в строку нашу вер регистра
		}

	}

}
