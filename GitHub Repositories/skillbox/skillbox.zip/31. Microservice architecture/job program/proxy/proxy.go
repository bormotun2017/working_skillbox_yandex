package main

import (
	"bytes"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
)

const proxyAdder string = "localhost:9000"

// -X POST -d "message to the second instance" http://localhost:9000/
var (
	counter            int    = 0 //счетчик запросов
	firstInstanceHost  string = "http://localhost:8080"
	secondInstanceHost string = "http://localhost:8082"
)

func main() {
	http.HandleFunc("/", handleProxe)                 // передаем ручку
	log.Fatalln(http.ListenAndServe(proxyAdder, nil)) //слушаем сервер
}
func handleProxe(w http.ResponseWriter, r *http.Request) {
	textBytes, err := ioutil.ReadAll(r.Body) //читаем тело запроса
	if err != nil {
		log.Fatalln(err)
	}
	text := string(textBytes) //переводим в строку полученный запрос

	if counter == 0 { // если счетчик равено 0, то отправляем запрос на первый сервер
		//text/plane - заголовок запроса,
		//bytes.newBuffer - создаем новый буфер байтов из нашей переменной text и отправляем его в запросе
		resp, err := http.Post(firstInstanceHost, "text/plain", bytes.NewBuffer([]byte(text)))
		if err != nil {
			log.Fatalln(err)
		}
		counter++
		textBytes, err = ioutil.ReadAll(resp.Body) // читаем тело нашего запроса
		if err != nil {
			log.Fatalln(err)
		}
		defer resp.Body.Close()
		fmt.Println(string(textBytes)) // выводим на экран

		return //возвращаемся, чтобы не идти дальше
		//далее мы попадем только если счетчик будет не равен 0, т.е. обработает наш запрос
	}
	if counter != 0 {
		resp, err := http.Post(secondInstanceHost, "text/plain", bytes.NewBuffer([]byte(text)))
		if err != nil {
			log.Fatalln(err)
		}

		textBytes, err = ioutil.ReadAll(resp.Body) // читаем тело нашего запроса
		if err != nil {
			log.Fatalln(err)
		}
		defer resp.Body.Close()
		fmt.Println(string(textBytes)) // выводим на экран
		counter--

	}
}
