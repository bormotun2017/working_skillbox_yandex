package main

import (
	"io/ioutil"
	"log"
	"net/http"
)

// curl -X POST -d "message to" http://localhost:8082/ запрос в cmd
const addr string = "localhost:8082"

func main() {
	http.HandleFunc("/", handle) //передаем хэндлер
	log.Fatalln(http.ListenAndServe(addr, nil))
}
func handle(w http.ResponseWriter, r *http.Request) { //создаем ручку
	bodyBytes, err := ioutil.ReadAll(r.Body) //читаем тело запроса
	if err != nil {
		log.Fatalln(err) // если ошибка, то заложим ее
	}
	defer r.Body.Close()                            //отложенный выход из тела запроса
	text := string(bodyBytes)                       //присваиваем переменной строку из полученных байтов
	response := []byte("2 instance " + text + "\n") //присваиваем 1 instanse+ полученный нами текст из запроса

	if _, err := w.Write(response); err != nil { //передаем байты в responsewriter
		log.Fatalln(err)
	}

}
