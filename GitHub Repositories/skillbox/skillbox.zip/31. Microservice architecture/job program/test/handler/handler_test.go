package handler

import (
	"io/ioutil"
	"net/http"
	"net/http/httptest"
	"testing"
)

//go test -v -count=1 ./handler/...

func TestHandler(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(handler)) //передаем наш handler d тест
	resp, err := http.Get(srv.URL)                       //шлем гет запрос на сервер
	if err != nil {
		t.Log(err)
		t.Fail()
	}
	textBytes, err := ioutil.ReadAll(resp.Body) // читаем текст запроса
	if err != nil {
		t.Log(err)
		t.Fail()
	}
	defer resp.Body.Close()
	text := string(textBytes) //переводим в стрингу
	if text != "message from test handler" { // если совпало то логируем и фэйлим
		t.Log(err)
		t.Fail()
	}
}
