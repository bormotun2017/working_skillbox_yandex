package main

//go mod init test //надо создавать go mod
//go test -v -count=1 .
//-v передает логи
//-count включает кэширование
//go test -v -count=1 -run TestAddV2
import "testing"

func TestAdd(t *testing.T) { // описание функ тест. Add имя функ которую будем тестировать
	exp := 5 //задаем переменные
	x := 3
	y := 2
	res := add(x, y) //передаем их в функ add

	if res != exp { //если res не равно правильному ответу
		t.Fail() //фэйлим
	}

	exp = 5 //задаем переменные
	x = 2
	y = 2
	res = add(x, y)
	if res != exp { //если res не равно правильному ответу
		t.Logf("4 не равно 5")

		t.Fail() //фэйлим
	}

}

// табличные тесты
func TestAddV2(t *testing.T) {

	for _, v := range []struct { // делаем цикл по структуре
		x   int
		y   int
		exp int
	}{
		{
			x:   1,
			y:   2,
			exp: 3,
		},
		{
			x:   2,
			y:   2,
			exp: 4,
		},
		{
			x:   5,
			y:   2,
			exp: 7,
		},
		{
			x:   5,
			y:   2,
			exp: 8,
		},
	} {
		res := add(v.x, v.y)
		if res != v.exp {
			t.Logf("%v не равно %v\n", res, v.exp)
			t.Fail()
		}

	}
}
