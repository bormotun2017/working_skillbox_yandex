package main

import "fmt"

func main() {
	var number1 int
	var number2 int
	fmt.Println("Эта программа находит минимум из 2х введенных чисел")
	fmt.Println("Введите первое число")
	fmt.Scan(&number1)
	fmt.Println("Введите второе число")
	fmt.Scan(&number2)
	fmt.Println("Число 1 - ", number1)
	fmt.Println("Число 2 - ", number2)
	if number1 > number2 {
		fmt.Println("Число 1 больше, чем число 2")
	} else if number1 < number2 {
		fmt.Println("Число 2 больше, чем число 1")
	} else {
		fmt.Println("Числа равны")
	}

}
