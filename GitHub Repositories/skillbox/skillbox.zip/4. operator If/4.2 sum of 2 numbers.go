package main

import "fmt"

func main() {
	var number1 int
	var number2 int
	var sum int
	var sumTrue int
	fmt.Println("Эта программа находит минимум из 2х введенных чисел")
	fmt.Println("Введите первое число")
	fmt.Scan(&number1)
	fmt.Println("Введите второе число")
	fmt.Scan(&number2)
	fmt.Println("Введите сумму этих чисел")
	fmt.Scan(&sum)
	sumTrue = number1 + number2 //верная сумма чисел
	fmt.Println("Число 1 - ", number1)
	fmt.Println("Число 2 - ", number2)

	if sum == sumTrue {
		fmt.Println("Сумма чисел: ", sum)
	} else {
		fmt.Println("Введенная вами сумма неверна\n"+
			"Верная сумма", sumTrue)
	}
}
