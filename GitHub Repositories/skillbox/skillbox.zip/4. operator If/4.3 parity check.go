package main

import "fmt"

func main() {
	var number1 int
	fmt.Println("Эта программа проверяет, четность введенного числа")
	fmt.Println("Введите число")
	fmt.Scan(&number1)
	if number1%2 == 0 {
		fmt.Println("Введенное число четное")
	} else {
		fmt.Println("Введенное число не четное")
	}
}
