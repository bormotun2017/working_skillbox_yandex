package main

import "fmt"

func main() {
	var experiencePoints int
	levelPlayer := 1
	fmt.Println("Эта программа вычисляет уровень игрока")
	fmt.Println("Введите очки опыта")
	fmt.Scan(&experiencePoints)
	if experiencePoints >= 5000 {
		levelPlayer = 4
		fmt.Println("Уровень персонажа ", levelPlayer)
	} else if experiencePoints >= 2500 {
		levelPlayer = 3
		fmt.Println("Уровень персонажа ", levelPlayer)
	} else if experiencePoints >= 1000 {
		levelPlayer = 2
		fmt.Println("Уровень персонажа ", levelPlayer)
	} else if experiencePoints > 0 {
		fmt.Println("Уровень персонажа ", levelPlayer)
	} else {
		fmt.Println("Введите число >0")
	}

}
