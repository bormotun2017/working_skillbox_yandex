package main

import "fmt"

func main() {
	fmt.Println("Введите стоимость товара:")
	var productCost int
	fmt.Scan(&productCost)

	fmt.Println("Введите стоимость доставки:")
	var deliveryCost int
	fmt.Scan(&deliveryCost)

	fmt.Println("Введите размер скидки:")
	var discount int
	fmt.Scan(&discount)

	if productCost >= 10000 {
		deliveryCost /= 2

		if productCost%2 == 0 { // вложенный цикл, проверка на четность
			fmt.Println("Покупателю положен подарок")
		}
	}

	price := productCost + deliveryCost - discount

	fmt.Println("------------")
	fmt.Println("Итого:", price)

}
