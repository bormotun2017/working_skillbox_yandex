package main

import "fmt"

func main() {
	fmt.Print("Эта программа выбирает капитана корабля\n" +
		"исходя из того, у кого больше iq\n")
	println("Введите iq первого космонавта")
	var astronaut1 int
	fmt.Scan(&astronaut1)

	println("Введите iq второго космонавта")
	var astronaut2 int
	fmt.Scan(&astronaut2)

	println("Введите iq третьего космонавта")
	var astronaut3 int
	fmt.Scan(&astronaut3)

	if astronaut1 > astronaut2 { //вложенный If если астронавт 1>2

		if astronaut1 > astronaut3 {
			fmt.Println("Капитан будет астронавт №1")

		} else {
			fmt.Println("Капитан будет астронавт №3")
		}
	}

	if astronaut2 > astronaut1 { //вложенный If если астронавт 2>1

		if astronaut2 > astronaut3 {
			fmt.Println("Капитан будет астронавт №2")
		} else {
			fmt.Println("Капитан будет астронавт №3")
		}

	}
}
