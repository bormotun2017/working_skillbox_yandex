package main

import "fmt"

func main() {
	var sumСheck int
	var day int
	fmt.Print("программа рассчитывает сумму скидки как 10% от суммы чека,\n" +
		" начиная с 10 000 руб, если этот день не будний.\n")
	fmt.Println("Введите день недели от 1го до 7")
	fmt.Scan(&day)
	if day > 0 && day <= 7 { //проверка правильности ввода дня недели
		fmt.Println("Введие сумму чека")
		fmt.Scan(&sumСheck)
		if sumСheck >= 10000 && day > 5 && day <= 7 { // вложенное условие
			fmt.Println("Сумма скидки: ", sumСheck*10/100)
		} else if day > 0 && day < 6 {
			fmt.Println("В будние дни скидки нет")

		}
	} else {
		fmt.Println("Выввели некорректное число")

	}
}
