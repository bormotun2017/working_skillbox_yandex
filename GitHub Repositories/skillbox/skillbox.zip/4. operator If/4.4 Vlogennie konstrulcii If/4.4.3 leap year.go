package main

import "fmt"

func main() {
	var year int
	fmt.Println("Программа выводит високосный год или нет")
	fmt.Println("Введите год")
	fmt.Scan(&year)
	if year%4 == 0 {

		if year%100 == 0 && year%400 == 0 {
			fmt.Println("Год високосный")
		} else if year%100 == 0 && year%400 != 0 {
			fmt.Println("Год не високосный")

		}
	} else {
		fmt.Println("Год не високосный")
	}
}
