package main

import "fmt"

func main() {
	fmt.Println("Эта программа угадывает введенное число")
	var number int
	var yesNo string
	fmt.Println("Введите задуманное число от 1го до 5")
	fmt.Scan(&number)
	if number > 0 && number < 6 {
		fmt.Println("Это число больше 3? да/нет")
		fmt.Scan(&yesNo)

		if yesNo == "да" {
			fmt.Println("Это число больше 4? да/нет")
			fmt.Scan(&yesNo)

			if yesNo == "да" {
				fmt.Println("Это число 5")
			}
			if yesNo == "нет" {
				fmt.Println("Это число 4")
			}

		}
		if yesNo == "нет" {
			fmt.Println("Это число меньше 3? да/нет")
			fmt.Scan(&yesNo)

			if yesNo == "нет" {
				fmt.Println("Это число 3")
			}
			if yesNo == "да" {
				fmt.Println("это число меньше 2? да/нет")
				fmt.Scan(&yesNo)

				if yesNo == "нет" {
					fmt.Println("Это число 2")
				}
				if yesNo == "да" {
					fmt.Println("это число 1")

				}
			}

		}
	} else {
		fmt.Println("Вы ввели некорректное число")
	}
}
