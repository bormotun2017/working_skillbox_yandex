package main

import "fmt"

func main() {
	var dividend int
	var divider int
	fmt.Println("Эта программа проверяет делиться ли одно число на 2е без остатка")
	fmt.Println("Введите делимое")
	fmt.Scan(&dividend)
	fmt.Println("Введите делитель")
	fmt.Scan(&divider)
	if dividend%divider == 0 {
		println("Делиться без остатка")
	} else {
		println("Не делиться без остатка")
	}

}
