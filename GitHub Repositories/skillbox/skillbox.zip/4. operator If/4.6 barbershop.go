package main

import "fmt"

func main() {
	fmt.Println("************* Барбершоп - калькулятор")
	fmt.Println("Введите число мужчин в городе:")
	var mansCount int
	fmt.Scan(&mansCount)

	fmt.Println("Сколько барберов уже удалось нанять?")
	var barberCount int
	fmt.Scan(&barberCount)

	//Сколько человек может постричь один барбер за одну смену?
	mansPerBarber := 8

	//Сколько человек он подстрижет за месяц
	mansPerBarberPerMounth := mansPerBarber * 30

	//Сколько нужно барберов подстричь mansPerDay человек?
	requiredBarbersCount := mansCount / mansPerBarberPerMounth
	if mansCount%mansPerBarberPerMounth != 0 {
		requiredBarbersCount++
	}
	fmt.Println("Необходимое число барберов", requiredBarbersCount)
	fmt.Println(requiredBarbersCount, "барбера могут постричь",
		mansPerBarberPerMounth*requiredBarbersCount, "мужчин за месяц")

	//Сравниваем с количеством имеющихся барберов
	if requiredBarbersCount > barberCount {
		fmt.Println("нужно больше барберов!")
	} else if requiredBarbersCount == requiredBarbersCount {
		fmt.Println("Барберов ровно столько, сколько нужно!")
	} else {
		fmt.Println("Барберов достаточно!")
	}
	if barberCount > requiredBarbersCount*2 {
		fmt.Println("Количество наших барберов более чем в 2 раза " +
			"превышает необходимое!")
	}
}
