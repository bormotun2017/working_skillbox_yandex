package main

import "fmt"

func main() {
	var number1 int
	var number2 int
	var number3 int
	counter := 0
	maxNumber := 5
	fmt.Println("Эта программа, которая сообщает, есть ли" +
		"среди введенных чисел число больше 5")
	fmt.Println("Введите первое число")
	fmt.Scan(&number1)

	if number1 >= maxNumber {
		counter++
	}
	fmt.Println("Введите второе число")
	fmt.Scan(&number2)

	if number2 >= maxNumber {
		counter++
	}
	fmt.Println("Введите третье число")
	fmt.Scan(&number3)

	if number3 >= maxNumber {
		counter++
	}

	if counter == 0 {
		fmt.Println("Среди введенных чисел нет числа больше 5")
	} else {
		fmt.Println("Среди введенных чисел", counter, "больше или равно ", maxNumber)
	}
}
