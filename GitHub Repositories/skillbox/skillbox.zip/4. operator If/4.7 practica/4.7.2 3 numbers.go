package main

import "fmt"

func main() {
	var number1 int
	var number2 int
	var number3 int
	maxNumber := 5
	fmt.Println("Эта программа, которая сообщает, есть ли" +
		"среди введенных чисел число больше 5")
	fmt.Println("Введите первое число")
	fmt.Scan(&number1)
	fmt.Println("Введите второе число")
	fmt.Scan(&number2)
	fmt.Println("Введите третье число")
	fmt.Scan(&number3)

	if number1 > maxNumber || number2 > maxNumber || number3 > maxNumber {
		fmt.Println("Среди введенных чисел есть число больше 5")
	} else {
		fmt.Println("Среди введенных чисел нет числа больше 5")
	}

}
