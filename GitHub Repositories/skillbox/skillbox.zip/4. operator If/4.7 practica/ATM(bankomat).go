package main

import "fmt"

func main() {
	sumMax := 100000
	sumMin := 100
	var sum int
	fmt.Println("Банкомат.")
	fmt.Println("Введите сумму снятия со счета:")
	fmt.Scan(&sum)

	if sum <= sumMax && sum%100 == 0 && sum >= sumMin { // проверка ввода
		fmt.Print("Операция успешно выполнена.\n"+
			"Вы сняли ", sum, " рублей.")
	} else {
		fmt.Println("Введите сумму кратную 100")
	}
}
