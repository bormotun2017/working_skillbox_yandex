package main

import "fmt"

func main() {
	var points1 int
	var points2 int
	var points3 int
	sumPoints := 275
	var sumPlayerPoints int

	fmt.Println("Баллы ЕГЭ.")
	fmt.Println("Введите результаты первого экзамена:")
	fmt.Scan(&points1)
	fmt.Println("Введите результаты второго экзамена:")
	fmt.Scan(&points2)
	fmt.Println("Введите результаты третьего экзамена:")
	fmt.Scan(&points3)
	sumPlayerPoints = points1 + points2 + points3
	fmt.Println("Сумма проходных баллов:", sumPoints)
	fmt.Println("Количество набранных баллов:", sumPlayerPoints)

	if sumPlayerPoints >= sumPoints {
		fmt.Println("Вы поступили.")
	} else {
		fmt.Println("Вы не поступили.")
	}

}
