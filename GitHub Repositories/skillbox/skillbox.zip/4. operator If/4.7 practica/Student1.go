package main

import "fmt"

func main() {
	var n int
	var k int
	var amountStudent int
	fmt.Println("Введите количество студентов")
	fmt.Scan(n)
	fmt.Println("Введите количество групп")
	fmt.Scan(k)
	fmt.Println("номер студента")

	amountStudent = n / k
	if n%k > 0 {
		fmt.Println("количество студентов в группе", amountStudent,
			"а в последней группе", amountStudent+1)
	}
}
