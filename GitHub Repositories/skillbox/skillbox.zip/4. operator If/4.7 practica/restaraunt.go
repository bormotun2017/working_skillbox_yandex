package main

import "fmt"

func main() {
	var dayWeek int
	var amountGuest int
	var sumCheckEnter int
	var sumCheck int
	var discount int
	var allowance int
	fmt.Println("Ресторан")
	fmt.Println("Введите день недели:")
	fmt.Scan(&dayWeek)

	if dayWeek > 0 && dayWeek < 8 { //проверка ввода дня недели
		fmt.Println("Введите число гостей:")
		fmt.Scan(&amountGuest)
		fmt.Println("Введите сумму чека")
		fmt.Scan(&sumCheckEnter)

		if dayWeek == 1 { //проверка скидок
			discount = 10
			fmt.Println("Скидка по понедельникам", sumCheckEnter*discount/100)
		} else if dayWeek == 5 && sumCheckEnter >= 10000 {
			discount = 5
			fmt.Println("Скидка по пятницам", sumCheckEnter*discount/100)
		} else {
			discount = 0
		}
	} else {
		fmt.Println("Введите число от 1 до 7")
	}

	if amountGuest > 5 { // проверка надбавок
		allowance = 10
		fmt.Println("Надбавка за оюслуживание", sumCheckEnter*allowance/100)
	} else {
		allowance = 0
	}
	sumCheck = sumCheckEnter - (sumCheckEnter * discount / 100) + (sumCheckEnter * allowance / 100)
	fmt.Println("Сумма к оплате:", sumCheck)
}
