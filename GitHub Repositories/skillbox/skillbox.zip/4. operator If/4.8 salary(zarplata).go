package main

import "fmt"

func main() {
	fmt.Println("Эта программа вычисляет разницу" +
		" между самой высокой и низкой зп и среднюю зп отдела")
	var salary1 int
	var salary2 int
	var salary3 int
	var salaryMax int
	var salaryMin int
	//	var salaryMin int
	//	var salaryAverage int
	fmt.Println("Введите зп первого сотрудника")
	fmt.Scan(&salary1)
	fmt.Println("Введите зп второго сотрудника")
	fmt.Scan(&salary2)
	fmt.Println("Введите зп третьего сотрудника")
	fmt.Scan(&salary3)
	//находим максимальную зп
	if salaryMax < salary1 {
		salaryMax = salary1
	}
	if salaryMax < salary2 {
		salaryMax = salary2
	}
	if salaryMax < salary3 {
		salaryMax = salary3
	}
	//находим минимальную зп
	salaryMin = salaryMax
	if salaryMin > salary1 {
		salaryMin = salary1
	}
	if salaryMin > salary2 {
		salaryMin = salary2
	}
	if salaryMin > salary3 {
		salaryMin = salary3
	}

	fmt.Println("зп первого сотрудника", salary1)
	fmt.Println("зп второго сотрудника", salary2)
	fmt.Println("зп третьего сотрудника", salary3)
	fmt.Println("разница между самой большой и самой маленькой зп - 156",
		salaryMax-salaryMin)
	fmt.Println("средняя зп отдела", (salary1+salary2+salary3)/3)
}
