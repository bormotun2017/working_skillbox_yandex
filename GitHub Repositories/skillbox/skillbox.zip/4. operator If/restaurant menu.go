package main

import "fmt"

func main() {
	var menuall string
	var menuday1 string
	var menuday2 string
	var menuday3 string
	var menuday4 string
	var menuday5 string
	var menuday6 string
	var menuday7 string
	var day int
	fmt.Println("Эта программа выводит меню ресторана в заданный день недели")
	menuall = "Борщ\n" +
		"Солянка\n" +
		"Рожки\n" +
		"Котлета\n"
	menuday1 = "Салат шуба\n" +
		"Жаркое\n"
	menuday2 = "Салат оливье\n" +
		"Судак\n"
	menuday3 = "Салат цезарь\n" +
		"Горбуша\n"
	menuday4 = "Салат мимоза\n" +
		"Запеканка\n"
	menuday5 = "Салат шеф\n" +
		"Пицца\n"
	menuday6 = "Салат куцый\n" +
		"бургер\n"
	menuday7 = "Салат ущерб\n" +
		"ребрышки\n"

	fmt.Println("Введите номер дня недели от 1 до 7")
	fmt.Scan(&day)
	if day == 1 {
		fmt.Print("Понедельник:\n", menuall, menuday1)
	} else if day == 2 {
		fmt.Print("Вторник:\n", menuall, menuday2)
	} else if day == 3 {
		fmt.Print("Среда:\n", menuall, menuday3)
	} else if day == 4 {
		fmt.Print("Вторник:\n", menuall, menuday4)
	} else if day == 5 {
		fmt.Print("Вторник:\n", menuall, menuday5)
	} else if day == 6 {
		fmt.Print("Вторник:\n", menuall, menuday6)
	} else if day == 7 {
		fmt.Print("Вторник:\n", menuall, menuday7)
	} else {
		fmt.Println("Введите число от 1го до 7")
	}
}
