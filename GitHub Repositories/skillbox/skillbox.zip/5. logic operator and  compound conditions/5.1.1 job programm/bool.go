package main

import "fmt"

func main() {
	var name string
	fmt.Scan(&name)

	var isUser bool
	isUser = true

	isAdmin := name == "admin" // проверкаб если вводим "admin", то isUser становится true
	fmt.Println(isUser, isAdmin)
}
