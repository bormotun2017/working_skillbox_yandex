package main

import "fmt"

func main() {
	var a, b, c int
	fmt.Scan(&a)
	fmt.Scan(&b)
	fmt.Scan(&c)

	isFirstNumberMax := true
	if b > a {
		isFirstNumberMax = false
	}
	if c > a {
		isFirstNumberMax = false
	}
	if isFirstNumberMax {
		fmt.Println("Первое число максимальное")
	} else {
		fmt.Println("Первое число не максимальное")
	}
}
