package main

import "fmt"

func main() {
	var a, b, c int
	fmt.Scan(&a)
	fmt.Scan(&b)
	fmt.Scan(&c)
	if a > b && a > c { // проверка макс числа
		fmt.Println(a)
	} else if b > c {
		fmt.Println(b)
	} else if c > b {
		fmt.Println(c)
	}

}
