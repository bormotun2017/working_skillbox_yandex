package main

import "fmt"

func main() {
	fmt.Println("Введите возраст первого ребенка")
	var firstChildAge int
	fmt.Scan(&firstChildAge)
	fmt.Println("Введите возраст второго ребенка")
	var secondChildAge int
	fmt.Scan(&secondChildAge)

	needSubsidy := false
	if firstChildAge > 3 && firstChildAge < 16 {
		needSubsidy = true
	}

	if secondChildAge > 3 && secondChildAge < 16 {
		needSubsidy = true
	}
	if needSubsidy {
		fmt.Println("Субсидия положена")
	} else {
		fmt.Println("Субсидия не положена")
	}
}
