package main

import "fmt"

func main() {
	var x, y int
	fmt.Println("Эта программа выводит к какой четверти координат" +
		"принадлежит точка")
	fmt.Println("Введите Х")
	fmt.Scan(&x)
	fmt.Println("Введите Y")
	fmt.Scan(&y)

	if x > 0 && y > 0 {
		fmt.Println("точка принадлежит к 1й четверти")
	} else if x < 0 && y > 0 {
		fmt.Println("точка принадлежит к 2й четверти")
	} else if x < 0 && y < 0 {
		fmt.Println("точка принадлежит к 3й четверти")
	} else if x > 0 && y < 0 {
		fmt.Println("точка принадлежит к 4й четверти")
	} else {
		fmt.Println("точка лежит на оси")
	}

}
