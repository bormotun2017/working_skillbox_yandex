package main

import "fmt"

func main() {
	var number1, number2, number3 int
	fmt.Println("Эта программа проверяет является ли" +
		" хотя бы одно введенное число положительным")
	fmt.Println("Введите первое число")
	fmt.Scan(&number1)
	fmt.Println("Введите второе число")
	fmt.Scan(&number2)
	fmt.Println("Введите третье число")
	fmt.Scan(&number3)
	var examenation = number1 > 0 || number2 > 0 || number3 > 0
	if examenation {
		fmt.Println("хотя бы одно введенное число положительное")
	} else {
		fmt.Println("среди введенных чисел нет положительных")
	}

}
