package main

import "fmt"

func main() {
	var number1, number2, number3 int
	fmt.Println("Эта программа проверяет совпадают ли" +
		" введенные числа")
	fmt.Println("Введите первое число")
	fmt.Scan(&number1)
	fmt.Println("Введите второе число")
	fmt.Scan(&number2)
	fmt.Println("Введите третье число")
	fmt.Scan(&number3)
	var examenation = number1 == number2 || number1 == number3 || number2 == number3
	if examenation {
		fmt.Println("2 или более числа совпадают")
	} else {
		fmt.Println("все числа разные")
	}

}
