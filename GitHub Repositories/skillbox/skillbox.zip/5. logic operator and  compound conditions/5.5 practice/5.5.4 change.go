package main

import "fmt"

func main() {
	var number1, number2, number3 int
	var price int
	fmt.Println("Эта программа проверяет сможет ли пользователь" +
		"заплатить за товар без сдачи или нет")
	fmt.Println("Введите стоимость")
	fmt.Scan(&price)
	fmt.Println("Введите первое число")
	fmt.Scan(&number1)
	fmt.Println("Введите второе число")
	fmt.Scan(&number2)
	fmt.Println("Введите третье число")
	fmt.Scan(&number3)
	var examenation = price == number1+number2+number3
	var examenation1 = price == number1+number2
	var examenation2 = price == number1+number3
	var examenation3 = price == number2+number3

	if price == number1 || price == number2 || price == number3 ||
		examenation || examenation1 || examenation2 || examenation3 {
		fmt.Println("Можно расплатиться без сдачи")
	} else {
		fmt.Println("Нельзя расплатиться без сдачи")
	}

}
