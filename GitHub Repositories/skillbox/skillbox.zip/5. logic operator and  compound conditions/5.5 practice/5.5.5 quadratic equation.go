package main

import (
	"fmt"
	"math"
)

func main() {
	fmt.Println(" Эта программа решает квадратное уравнение")
	var a, b, c, d, x, x1, x2 float64
	fmt.Println("Введите a")
	fmt.Scan(&a)
	fmt.Println("Введите b")
	fmt.Scan(&b)
	fmt.Println("Введите c")
	fmt.Scan(&c)
	d = math.Pow(b, 2) - 4*a*c
	if d > 0 {
		x1 = (-b - math.Sqrt(d)) / (2 * a)
		x2 = (-b + math.Sqrt(d)) / (2 * a)
		fmt.Println("Дискриминант больше 0\n"+
			"x1:", x1, "\n"+
			"x2:", x2)
	} else if d == 0 {
		x = (-b) / (2 * a)
		fmt.Println("Дискиминант равен 0\n"+
			"x", x)
	} else if d < 0 {
		fmt.Println("Корней нет")
		fmt.Println(d)
	}

}
