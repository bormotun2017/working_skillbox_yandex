package main

import "fmt"

func main() {
	fmt.Println("Эта программа вычисляет является ли номер билета счастливым" +
		", зеркальным или обычным")
	var numberTicket int
	var a1, a2, a3, a4 int
	fmt.Println("Введите номер билета")
	fmt.Scan(&numberTicket)
	a1 = numberTicket % 10
	a2 = numberTicket / 10 % 100 % 10
	a3 = numberTicket / 100 % 1000 % 10
	a4 = numberTicket / 1000 % 10000
	var happyTicket = (a4 + a3) == (a1 + a2)
	var mirrorTicket = a4 == a1 && a2 == a3

	if mirrorTicket {
		fmt.Println("Билет зеркальный")
	} else if happyTicket {
		fmt.Println("Билет счастливый")
	} else {
		fmt.Println("Билет обычный")

	}

}
