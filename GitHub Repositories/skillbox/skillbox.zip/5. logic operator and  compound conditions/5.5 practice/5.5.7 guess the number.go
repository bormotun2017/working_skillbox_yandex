package main

import "fmt"

func main() {
	fmt.Println("Эта программа угадывает введенное число")
	var number int
	var yesNo string
	fmt.Println("Введите задуманное число от 1го до 10")
	fmt.Scan(&number)
	if number > 0 && number < 11 { // проверка ввода
		if number == 6 { // если ввели 6 угадываем сразу
			fmt.Println("это число 6")
		} else {
			fmt.Println("Это число больше 6? да/нет")
			fmt.Scan(&yesNo)

			if yesNo == "да" { // блок проверки если ввели больше 6
				fmt.Println("Это число больше 8? да/нет")
				fmt.Scan(&yesNo)

				if yesNo == "да" {
					fmt.Println("Это число больше 9? да/нет")
					fmt.Scan(&yesNo)

					if yesNo == "да" {
						fmt.Println("Это число 10")
					}
					if yesNo == "нет" {
						fmt.Println("Это число 9")
					}

				} else {
					fmt.Println("Это число меньше 8? да/нет")
					fmt.Scan(&yesNo)

					if yesNo == "да" {
						fmt.Println("Это число 7")
					} else {
						fmt.Println("Это число 8")
					}
				}
			}

			if yesNo == "нет" { // блок проверки если ввели меньше 6
				fmt.Println("Это число больше 2? да/нет")
				fmt.Scan(&yesNo)

				if yesNo == "да" {
					fmt.Println("Это число больше 4? да/нет")
					fmt.Scan(&yesNo)

					if yesNo == "да" {
						fmt.Println("Это число 5")
					}
					if yesNo == "нет" {
						fmt.Println("Это число 4")
					}

				} else {
					fmt.Println("Это число меньше 2? да/нет")
					fmt.Scan(&yesNo)

					if yesNo == "да" {
						fmt.Println("Это число 1")
					} else {
						fmt.Println("Это число 2")
					}
				}

			}

		}

	} else {
		fmt.Println("Вы ввели некорректное число")
	}
}
