package main

import "fmt"

func main() {
	fmt.Println("Эта программа принимает от пользователя число и выводит" +
		"в цикле все числа от 0 до указанного числа")
	var number int
	fmt.Println("Введите число")
	fmt.Scan(&number)

	for i := 0; i != number; {
		if number > 0 {
			fmt.Println(i)
			i += 1
		} else if number < 0 {
			fmt.Println(i)
			i -= 1
		}
	}
	fmt.Println(number)
}
