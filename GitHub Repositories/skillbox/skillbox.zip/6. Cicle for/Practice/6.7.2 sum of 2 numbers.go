package main

import "fmt"

func main() {
	var number1, number2, sum int
	//Напишите программу, которая запрашивает у пользователя два числа
	//и складывает их в цикле следующим образом: берёт первое число
	//и прибавляет к нему по единице, пока не достигнет суммы двух чисел.

	fmt.Println("Введите первое число")
	fmt.Scan(&number1)
	fmt.Println("Введите второе число")
	fmt.Scan(&number2)
	sum = number1 + number2
	for number1 <= sum {
		number1 += 1

	}
	fmt.Println("Сумма чисел равна", number1)

}
