package main

import "fmt"

func main() {
	fmt.Println("Эта программа расчитывает сумму скидки")
	var price, discount, sumDiscount float64
	fmt.Println("Введите цену товара")
	fmt.Scan(&price)
	fmt.Println("Введите скидку не больше 30 %")
	fmt.Scan(&discount)
	sumDiscount = price * (discount / 100)
	fmt.Println(sumDiscount)

	if sumDiscount <= price*0.3 && sumDiscount <= 2000 {
		fmt.Println("сумма скидки:", sumDiscount)
	} else {
		fmt.Println("Либо вы ввели больше 30, либо сумма скидки больше 2000")
	}
}
