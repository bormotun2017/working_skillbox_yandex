package main

import "fmt"

func main() {
	//Представьте, что у вас есть три корзины разной ёмкости.
	//Пользователю предлагается ввести, какое количество яблок помещается в каждую корзину.
	//После этого программа должна заполнить все корзины по очереди
	//учитывая, какие корзины уже заполнены, строго соблюдая очерёдность заполнения
	//и добавляя по одному яблоку в каждой итерации.
	var baskets1, baskets2, baskets3, a, b, c int
	fmt.Println("Введите емкость первой корзины")
	fmt.Scan(&a)
	fmt.Println("Введите емкость второй корзины")
	fmt.Scan(&b)
	fmt.Println("Введите емкость третьей корзины")
	fmt.Scan(&c)

	for {

		if a != 0 {
			baskets1 += 1
			a -= 1
			continue
		}
		if b != 0 {
			baskets2 += 1
			b -= 1
			continue
		}
		if c != 0 {
			baskets3 += 1
			c -= 1
			continue

		} else {
			break
		}

	}
	fmt.Println(baskets1, baskets2, baskets3)

}
