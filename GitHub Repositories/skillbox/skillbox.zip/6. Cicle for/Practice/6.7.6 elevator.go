package main

import "fmt"

func main() {

	minFloor := 1     // мин этаж
	maxFloor := 24    // макс этаж
	currentFloor := 1 // этаж на котором лифт
	direction := 1    // направление движения

	maxPassenger := 2    // макс пассаж в лифте
	totalPassangers := 0 // сейчас пассажиров в лифте

	passenger1 := 4  // 1й пассажир
	passenger2 := 7  // 2й пассажир
	passenger3 := 10 // 3 пассажир

	for passenger1 != minFloor || passenger2 != minFloor || passenger3 != minFloor || currentFloor != minFloor {
		currentFloor += direction
		fmt.Printf("Лифт находится на этаже: %v, Количество пассажиров: %v\n", currentFloor, totalPassangers)

		if direction == 1 && currentFloor == maxFloor {
			direction = -1
		} else if currentFloor == minFloor {
			direction = 1
			totalPassangers = 0
		} else if direction == -1 {
			if passenger1 == currentFloor && totalPassangers < maxPassenger {
				fmt.Printf("Забираем первого пассажира с этажа %v\n", currentFloor)
				passenger1 = 1
				totalPassangers++
			}
			if passenger2 == currentFloor && totalPassangers < maxPassenger {
				fmt.Printf("Забираем второго пассажира с этажа %v\n", currentFloor)
				passenger2 = 1
				totalPassangers++
			}
			if passenger3 == currentFloor && totalPassangers < maxPassenger {
				fmt.Printf("Забираем третьего пассажира с этажа %v\n", currentFloor)
				passenger3 = 1
				totalPassangers++
			}
		}
	}
}
