package main

import "fmt"

func main() {
	fmt.Println("Эта программа выводит 3 одинаковых сообщения")
	for i := 0; i < 3; i += 1 {
		println("Одинаковые сообщения")
	}
}
