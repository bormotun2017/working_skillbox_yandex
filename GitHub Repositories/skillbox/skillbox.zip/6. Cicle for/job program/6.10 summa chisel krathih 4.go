package main

import "fmt"

func main() {
	checkNumber := 0
	var counter int
	fmt.Println("Эта программа складывает все числа кратные 4м в диапазоне от 0 до 40")

	for checkNumber <= 40 {
		checkNumber += 1

		if checkNumber%4 != 0 {
			continue
		}
		counter += checkNumber

	}
	fmt.Println(counter)
}
