package main

import "fmt"

func main() {
	var number, sum int
	fmt.Println("Эта программа складывает 4 произвольных числа")
	for i := 1; i < 5; i += 1 {
		fmt.Println("Введите", i, "число")
		fmt.Scan(&number)
		sum += number
	}
	fmt.Println("сумма введенных чисел", sum)
}
