package main

import (
	"fmt"
)

func main() {
	var number, degree int
	fmt.Println("Эта программа возводит число в нужную степень от 0 и выше")
	fmt.Println("введите число")
	fmt.Scan(&number)
	fmt.Println("введите степень")
	fmt.Scan(&degree)

	if degree == 0 {
		fmt.Println("1")
	} else if degree > 0 {
		for i := 1; i < degree; i += i {
			number *= number
		}
		fmt.Println(number)
	} else {
		fmt.Println("Вы ввели отрицательное число")
	}

}
