package main

import "fmt"

const password = "123"

func main() {
	passwordEnter := "123"
	fmt.Println("Эта программа спрашивает пароль и выходит из цикла с помощью break")
	for {
		fmt.Println("Введите пароль")
		fmt.Scan(&passwordEnter)
		if passwordEnter == password {
			break
		}
	}
}
