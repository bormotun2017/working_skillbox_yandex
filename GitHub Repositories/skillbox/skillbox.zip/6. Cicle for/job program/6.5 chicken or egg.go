package main

import "fmt"

func main() {
	var answer string
	fmt.Println("Эта программа спорит с пользователем, о том что было раньше курица или яйцо?")
	for {
		fmt.Println("что было раньше курица или яйцо")
		fmt.Scan(&answer)

		if answer == "надоело" {
			break

		} else {
			fmt.Println("яйцо")
		}
	}
	fmt.Println("программа победила")
}
