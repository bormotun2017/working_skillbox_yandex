package main

import "fmt"

func main() {
	var i int
	for {
		i += 1
		fmt.Println(i)
	}
}
