package main

import "fmt"

func main() {
	var counter int
	counter = 0

	for {
		counter += 1
		fmt.Println(counter)
		if counter == 0 {
			fmt.Println("прошли кпп")
		}

		if counter == 10 {

			for counter >= -10 {
				counter -= 1
				fmt.Println(counter)

				if counter == 0 {
					fmt.Println("прошли кпп")
				}
			}

		}
	}
}