package main

import "fmt"

func main() {
	checkNumber := 0
	prizes := 10

	for checkNumber < 100 {
		checkNumber += 1
		fmt.Println("Чек №", checkNumber)

		if checkNumber%10 != 0 {
			continue
		}
		fmt.Println("Выдать приз")
		fmt.Println("Купон на скидку")
		fmt.Println("Осталось призов", prizes)

		prizes -= 1
	}
}
