package main

import "fmt"

func main() {
	checkNumber := 0
	fmt.Println("Эта программа выводит числа кратные 2м в диапазоне от 0 до 10")

	for checkNumber < 10 {
		checkNumber += 1

		if checkNumber%2 != 0 {
			continue
		}
		fmt.Println(checkNumber)

	}
}
