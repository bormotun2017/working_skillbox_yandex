package main

import "fmt"

const rightAnswer = "25"

func main() {
	userAnswer := ""

	for i := 0; i < 3; i += 1 {
		fmt.Println("Введите результат умножения 5 на 5")
		fmt.Scan(&userAnswer)

		if userAnswer == rightAnswer {
			fmt.Println("Правильно!, экзамен пройден")
			return
		}
		fmt.Println("Неправильно! Попробуйте еще раз")
	}
	fmt.Println("Вы использовали 3 попытки. Экзамен не пройден")
}
