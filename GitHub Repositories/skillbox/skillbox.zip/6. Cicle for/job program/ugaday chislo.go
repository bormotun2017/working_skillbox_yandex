package main

import "fmt"

func main() {
	fmt.Println("Загадайте число от 1го до 10")

	min := 1
	max := 10
	numberFounded := false
	i := 0
	for i < 4 {
		num := (min + max) / 2
		fmt.Println("Загаданное число", num, "? Введите знак '>'"+
			"число больше, '<' если число меньше")
		var answer string
		fmt.Scan(&answer)
		if answer == ">" {
			min = num + 1
		} else if answer == "<" {
			max = num - 1
		} else if answer == "=" {
			fmt.Println("Ура! Число угадано")
			return
		} else {
			fmt.Println("некорректный ввод")
		}

	}
}
