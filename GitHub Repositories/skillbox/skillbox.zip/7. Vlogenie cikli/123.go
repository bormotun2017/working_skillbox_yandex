package main

import "fmt"

func main() {
	var height int
	fmt.Println("Введите высоту елочки")
	fmt.Scan(&height)
	space := " "
	star := "*"
	var line string
	for i := 1; i <= height; i++ {
		for j:=1; j<=height; j =+2 {
			if
		}

	}
}