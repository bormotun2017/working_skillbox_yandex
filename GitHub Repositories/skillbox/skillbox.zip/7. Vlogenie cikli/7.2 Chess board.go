package main

import (
	"fmt"
)

func main() {
	fmt.Println("Эта программа выводит шахматную доску заданных размеров")
	var height, width int
	fmt.Println("Введите ширину")
	fmt.Scan(&width)
	fmt.Println("Введите высоту")
	fmt.Scan(&height)

	for i := 1; i <= height; i++ {
		if i%2 == 0 {
			for j := 0; j <= width; j += 2 {
				fmt.Print("*")
				fmt.Print(" ")
			}
		} else {
			for j := 2; j <= width; j += 2 {
				fmt.Print(" ")
				fmt.Print("*")
			}
		}
		fmt.Println()
	}
}
