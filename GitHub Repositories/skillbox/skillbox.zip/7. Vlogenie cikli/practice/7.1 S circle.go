package main

import (
	"fmt"
	"math"
)

func main() {
	fmt.Println("Введите радиус окружности")
	var r float64
	fmt.Scan(&r)
	s := math.Pi * math.Pow(r, 2)
	fmt.Println(s)
}
