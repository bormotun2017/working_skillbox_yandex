package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	rand.Seed(time.Now().UnixNano()) // seed рандом
	for {
		a := rand.Intn(9) + 1
		b := rand.Intn(9) + 1

		for {
			var result int
			fmt.Print(a, "*", b, "=")
			fmt.Scan(&result)
			if a*b != result {
				fmt.Println("Ответ не правильныйб попробуйте еще")
			} else {
				break
			}
		}
		fmt.Println("Ответ правильный")

		fmt.Println("Еще пример? (да/нет)")
		var answer string
		fmt.Scan(&answer)

		for answer != "да" && answer != "нет" {

			fmt.Println("Еще пример? (да/нет)")
			fmt.Scan(&answer)
		}
		if answer == "нет" {
			break
		}
	}

}
