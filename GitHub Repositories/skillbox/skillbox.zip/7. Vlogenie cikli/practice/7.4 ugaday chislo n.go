package main

import "fmt"

func main() {
	fmt.Println("Введите до какого числа вы будете загадывать число")
	var n int
	fmt.Scan(&n)
	i := 0
	min := 1
	max := n
	for {
		current := (min + max) / 2
		fmt.Println("Загаданное число", current, "?")
		var answer string
		fmt.Scan(&answer)
		if answer == ">" {
			min := current + 1
		} else if answer == "<" {
			max = current - 1
		} else {
			fmt.Println("Ура")
			break
		}
	}
	fmt.Println("Угадано с попытки", i)
}
