package main

import "fmt"

func main() {
	var word string
	fmt.Println("Введите месяц с января по декабрь")
	fmt.Scan(&word)
	switch word {
	case "декабрь", "январь", "февраль":
		fmt.Println("на дворе зима")
	case "март", "апрель", "май":
		fmt.Println("на дворе весна")
	case "июнь", "июль", "август":
		fmt.Println("на дворе лето")
	case "сентябрь", "октябрь", "ноябрь":
		fmt.Println("на дворе осень")
	default:
		fmt.Println("Вы что то не так ввели")

	}
}
