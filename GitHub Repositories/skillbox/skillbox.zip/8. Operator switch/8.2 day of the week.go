package main

import "fmt"

func main() {
	fmt.Println("Эта программа выводит последующие дни недели")
	var word string
	fmt.Println("Введите день недели в сокращенном формате с пн по пт")
	fmt.Scan(&word)
	switch word {
	case "пн":
		fmt.Println("понедельник")
		fallthrough
	case "вт":
		fmt.Println("вторник")
		fallthrough
	case "ср":
		fmt.Println("среда")
		fallthrough
	case "чт":
		fmt.Println("четверг")
		fallthrough
	case "пт":
		fmt.Println("пятница")
		fallthrough
	default:
		fmt.Println("Вы что то не так ввели")

	}

}
