package main

import "fmt"

func main() {
	fmt.Println("Введите сумму доходов")
	var income, tax float64
	fmt.Scan(&income)
	switch {
	case income >= 7000:
		tax = (income - 70000) * 50 / 100
		fmt.Println("Сумма налога свыше 70000 составляет 50 % и равна", tax)
		fallthrough
	case income >= 50000:
		tax = (income - 50000) * 30 / 100
		fmt.Println("сумма налога свыше 50000 составляет 30% и равен", tax)
		income = 50000
		fallthrough
	case income >= 10000:
		tax = (income - 10000) * 20 / 100
		fmt.Println("сумма налога свыше 10000 составляет 20% и равен", tax)
		income = 10000
		fallthrough
	case income > 0:
		tax = income * 13 / 100
		fmt.Println("сумма налога до 10000 составляет 13% и равен", tax)
	default:
		fmt.Println("доход должен быть положительным")

	}
}
