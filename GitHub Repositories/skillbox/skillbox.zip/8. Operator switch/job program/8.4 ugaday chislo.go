package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {

	rand.Seed(time.Now().UnixNano())
	n := rand.Intn(101)
outerLoop:
	for {
		var answer int

	innerloop:
		for {
			fmt.Scan(&answer)
			switch {
			case answer < 1 || answer > 100:
				fmt.Println("Число должно быть в диапазоне от 0 до 100")
			default:
				break innerloop
			}
		}
		switch {
		case answer == n:
			fmt.Println("Ура!!! Вы угадали число")
			break outerLoop
		case answer < n:
			fmt.Println("Загаданное число больше")
		default:
			fmt.Println("Загаданное число меньше")

		}
	}
}
