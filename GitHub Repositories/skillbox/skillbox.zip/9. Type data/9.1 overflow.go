package main

import (
	"fmt"
	"math"
)

func main() {
	var a uint8
	var b uint16
	var countA, countB int

	for i := 0; i != math.MaxUint32; i++ {
		a++
		b++
		if a == math.MaxUint8 {
			countA++

		}
		if b == math.MaxUint16 {
			countB++

		}
	}
	fmt.Printf("переполнений Uint8: %d\n", countA)
	fmt.Printf("переполнений Uint16: %d\n", countB)

}
