package main

import (
	"fmt"
	"math"
	"reflect"
)

func main() {
	var enter1, enter2 int16
	var sum int32
	var typeUint8 uint8
	var typeInt8 int8
	var typeUint16 uint16
	var typeInt16 int16
	var typeUint32 uint32
	var typeInt32 int32
	fmt.Println("Эта программа сохраняет сумму 2х чисел в наименьшем типа данных")
	fmt.Printf("введите 2 числа в диапазоне от %d до %d \n", -1<<16, math.MaxUint16+1)
	fmt.Scan(&enter1)
	fmt.Scan(&enter2)
	sum = int32(enter1) * int32(enter2)
	fmt.Println(sum)
	if sum >= math.MinInt8 && sum < 0 {
		fmt.Println(sum, "результат", reflect.TypeOf(typeInt8))
	} else if sum >= 0 && sum <= math.MaxUint8 {
		fmt.Println(sum, "результат", reflect.TypeOf(typeUint8))
	} else if sum >= math.MinInt16 && sum < math.MinInt8 {
		fmt.Println(sum, "результат", reflect.TypeOf(typeInt16))
	} else if sum > math.MaxUint8 && sum <= math.MaxUint16 {
		fmt.Println(sum, "результат", reflect.TypeOf(typeUint16))
	} else if sum >= math.MinInt32 && sum < math.MinInt16 {
		fmt.Println(sum, "результат", reflect.TypeOf(typeInt32))
	} else if sum > math.MaxUint16 && uint32(sum) <= math.MaxUint32 {
		fmt.Println(sum, "результат", reflect.TypeOf(typeUint32))
	}

}
