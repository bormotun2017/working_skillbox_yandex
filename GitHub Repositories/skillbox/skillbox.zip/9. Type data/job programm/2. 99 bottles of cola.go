package main

import "fmt"

func main() {
	var i uint16 = 10
	for ; i != (1<<16 - 2); i-- {
		if i == 0 {
			fmt.Println("кола закончилась но...")
			fmt.Println("мы начнем сначала")
			continue
		}
		fmt.Printf("осталось бутылок %d \n", i)
	}
}
