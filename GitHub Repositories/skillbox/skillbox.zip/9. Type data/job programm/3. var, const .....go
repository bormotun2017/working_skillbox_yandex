package main

import "fmt"

var countOranges = 10
var (
	countGreenApples = 5
	countRedApples   = 7
)

const (
	firstSpartian uint16 = 1 + iota
	secondSpartian
	thirdSpartian
	fourthSpartian
	fifthSpartian
)

func main() {
	fmt.Printf("1й спартанец под номером %d \n", firstSpartian)
	fmt.Printf("1й спартанец под номером %d \n", secondSpartian)
	fmt.Printf("1й спартанец под номером %d \n", thirdSpartian)
	fmt.Printf("1й спартанец под номером %d \n", fourthSpartian)
	fmt.Printf("1й спартанец под номером %d \n", fifthSpartian)
}
