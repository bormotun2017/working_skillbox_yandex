package main

import "fmt"

const (
	twoInZero = 1 << iota
	_
	twoInTwo
	_
	twoInFour
)

func main() {
	fmt.Println(twoInZero)
	fmt.Println(twoInTwo)
	fmt.Println(twoInFour)

}
