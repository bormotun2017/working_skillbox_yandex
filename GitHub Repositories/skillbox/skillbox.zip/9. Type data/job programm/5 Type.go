package main

import (
	"fmt"
	"math"
)

func main() {

	type orangeCount int
	type appleCount int
	type fruitsCount int
	oranges := orangeCount(5)
	apples := appleCount(7)
	fruits := fruitsCount(oranges) + fruitsCount(apples)
	fmt.Println(oranges)
	fmt.Println(apples)
	fmt.Println(fruits)
	fmt.Print(math.MaxInt)
}
