package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	rand.Seed(time.Now().UnixNano())

	for i := 0; i < 10; i++ {
		a := -10 + rand.Intn(1<<5)
		fmt.Println(a)

	}

}
