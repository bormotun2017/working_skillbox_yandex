package main

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/gin-gonic/gin"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"
)

func main() {
	// G I N - G O N I C
	handler := gin.New() // задаем хэндлер гин гоника

	accounts := gin.Accounts{
		"test": "test",
		"foo":  "bar", // user: foo password: bar
		"manu": "123",
	}

	handler.Use(gin.BasicAuth(accounts), gin.Logger(), gin.Recovery()) //Logger() // встроенная авторизация по гину

	book := handler.Group("/book")
	{
		book.GET("/:id", handleGetBook) // надо в хэндлер передавать *gin.Context вместо response writer и request
		// handleGetBook(с *gin.Context) * gin Context содержит writer и request в качестве своих полей
		book.POST("/", handleAddBook)
		book.PUT("/:id", handleUpdateBook)
		book.DELETE("/:id", handleDeleteBook)
	}
	handler.GET("/books/", handleGetBook)

	///G O R I L L A

	//r := mux.NewRouter()                            // задаем роутер
	//r.Use(Logger, BasicAuth)                        //задаем midlewahre
	//bookrouter := r.PathPrefix("/book").Subrouter() // задаем методы работы, которые будут после слова /book
	//{
	//	bookrouter.HandleFunc("/", handleAddBook).Methods("POST") // /book/, обработает если метод POST
	//	bookrouter.HandleFunc("/{id}", handleGetBook).Methods("GET") //можно передать поле id без доп функ
	//	bookrouter.HandleFunc("/{id}", handleUpdateBook).Methods("PUT")
	//	bookrouter.HandleFunc("/{id}", handleDeleteBook).Methods("DELETE")
	//}
	//r.HandleFunc("books/", handleGetBook).Methods("GET")

	handler := http.NewServeMux()                                  // задаем хэндлер(обработчик запросов)
	handler.HandleFunc("/hello/", Logger(BasicAuth(helloHandler))) // завернули хэндлфунк в логгер и это все еще в функ авторизации
	// "" - название запроса который будет в ад строке
	// 2м номером идет функция которая будет его обрабатывать

	//C R U D
	handler.HandleFunc("/book/", Logger(bookHandler))

	handler.HandleFunc("/books/", Logger(booksHandler))

	s := &http.Server{ //наш сервер с настройками
		Addr:           ":8080",          // ,будет на любом ip с этим портом например 127.0.0.1:8080
		Handler:        handler,          //указываем хэндлер
		ReadTimeout:    10 * time.Second, //всякие полезные таймы обработки
		WriteTimeout:   10 * time.Second,
		IdleTimeout:    10 * time.Second,
		MaxHeaderBytes: 1 << 20, //1*2 ^20 - 128 kb
	}

	go func() { //запускаем сервер в отдельной го рутине
		log.Printf("Listening on http://%s\n", s.Addr)
		log.Fatal(s.ListenAndServe())
	}()

	graceful(s, 5*time.Second) // в течении 5 секунд еще обрабатываем входящие запросы, потом дообрабатываем все что собрали
}

//	log.Fatalln(s.ListenAndServe()) // запуск сервера в логфатале, чтобы вернуть ошибку если что

//}

func graceful(hs *http.Server, timeout time.Duration) { // graceful shutdown
	stop := make(chan os.Signal, 1) // создаем канал

	signal.Notify(stop, os.Interrupt, syscall.SIGTERM) // завершит канал когда получит сигнал

	<-stop // получили сигнал

	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()

	log.Printf("nShutdown with timeout: %s\n", timeout)

	if err := hs.Shutdown(ctx); err != nil {
		log.Printf("Error: %v\n", err)

	} else {
		log.Println("Server stopped")
	}

}

type Resp struct { // json структура для работы с данными
	Message interface{} `json:"message"` //тип интерфейс, чтобы передавать в функции интерфейс
	Error   string      `json:"error"`
}

type Book struct { //тип дял книг
	Id     string `json:"id"`
	Author string `json:"author"`
	Name   string `json:"name"`
}

type BookStore struct { // тип для хранения книг
	books []Book
}

func helloHandler(w http.ResponseWriter, r *http.Request) { //функция обработки запроса
	w.Header().Set("Content-Type", "application/json") // обясняем хэдэру, что будем работать с json

	//r.URL.Path содержит весь пусть запроса
	name := strings.Replace(r.URL.Path, "/hello/", "", 1) // name получит то что мы ввели после / в запросе
	//						откуда		что меняем		на что	сколько раз

	resp := Resp{
		Message: fmt.Sprintf("hello %s. Glad to see you again", name), // полю можно задать функцию )) круто
	}
	respJson, _ := json.Marshal(resp) // записываем нашу структуру в json

	w.WriteHeader(http.StatusOK) // возвращаем статус ок
	w.Write(respJson)
}

func Logger(next http.HandlerFunc) http.HandlerFunc { //логгер который будет перехватывать midlewear
	return func(w http.ResponseWriter, r *http.Request) { //возвращаем функцию
		w.Header().Set("Content-Type", "application/json") // обясняем хэдэру, что будем работать с json

		log.Printf("server [net/http] method [%s] connecion from [%v]", r.Method, r.RemoteAddr)

		next.ServeHTTP(w, r)
	}
}

func bookHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodGet { // если был вызван метод гет
		handleGetBook(w, r) // то вызываем другую функцию
	} else if r.Method == http.MethodPost { // если пост вызываем добавить книгу
		handleAddBook(w, r)
	} else if r.Method == http.MethodPost { // если пост вызываем добавить книгу
		handleAddBook(w, r)
	} else if r.Method == http.MethodDelete { // если пост вызываем добавить книгу
		handleDeleteBook(w, r)
	} else if r.Method == http.MethodPut { // если пост вызываем добавить книгу
		handleUpdateBook(w, r)
	}

}

func BasicAuth(next http.HandlerFunc) http.HandlerFunc { //тоже midlewahre для авторизации пользвателя
	//Basic kkjkjkjkj login:pass
	return func(w http.ResponseWriter, r *http.Request) {

		auth := strings.SplitN(r.Header.Get("Authorization"), " ", 2)

		if len(auth) != 2 || auth[0] != "Basic" {
			http.Error(w, "authorization failed", http.StatusUnauthorized)

			return
		}

		hashed, _ := base64.StdEncoding.DecodeString(auth[1]) // декодирем строку auth[1]

		pair := strings.SplitN(string(hashed), ":", 2)

		if len(pair) != 2 || !bauth(pair[0], pair[1]) {
			http.Error(w, "authorization failed", http.StatusUnauthorized)

			return

		}

		//next.ServeHTTP(w,r)

	}

}

func bauth(username, password string) bool {

	if username == "test" && password == "test" {
		return true
	}

	return false

}

func handleUpdateBook(w http.ResponseWriter, r *http.Request) {
	id := strings.Replace(r.URL.Path, "/book/", "", 1) // берем id из адреса запроса

	decoder := json.NewDecoder(r.Body) // присваиваем переменной json декодер

	var book Book
	var resp Resp

	err := decoder.Decode(&book) //передаем адрес на книгу

	if err != nil {
		w.WriteHeader(http.StatusBadRequest)

		resp.Error = err.Error()

		respJson, _ := json.Marshal(resp)

		w.Write(respJson)

		return
	}

	book.Id = id

	err = bookStore.UpdateBook(book) //ищем по базе

	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		resp.Error = err.Error()
		respJson, _ := json.Marshal(resp)
		w.Write(respJson)
		return
	}
	resp.Message = book

	respJson, _ := json.Marshal(resp)

	w.WriteHeader(http.StatusOK)

	w.Write(respJson)

}

func handleDeleteBook(w http.ResponseWriter, r *http.Request) {
	id := strings.Replace(r.URL.Path, "/book/", "", 1) // берем id из адреса запроса

	var resp Resp

	err := bookStore.DeleteBook(id) //ищем по базе

	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		resp.Error = err.Error()
		respJson, _ := json.Marshal(resp)
		w.Write(respJson)
		return
	}

	booksHandler(w, r)

}

func handleAddBook(w http.ResponseWriter, r *http.Request) {
	decoder := json.NewDecoder(r.Body) // присваиваем переменной json декодер

	var book Book
	var resp Resp

	err := decoder.Decode(&book) //передаем адрес на книгу

	if err != nil { // если ошибка при декодинге передадим статус 400
		w.WriteHeader(http.StatusBadRequest)

		resp.Error = err.Error()

		respJson, _ := json.Marshal(resp)

		w.Write(respJson)

		return
	}
	//если добавляют то, что уже существует
	err = bookStore.AddBooks(book)
	if err != nil { // если ошибка при декодинге передадим статус 400
		w.WriteHeader(http.StatusBadRequest)

		resp.Error = err.Error()

		respJson, _ := json.Marshal(resp)

		w.Write(respJson)

		return

	}
	booksHandler(w, r)
}

func booksHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodGet { // если был вызван метод гет
		handleGetBook(w, r) // то вызываем другую функцию
	}
	w.WriteHeader(http.StatusOK)

	resp := Resp{
		Message: bookStore.GetBooks(),
	}

	booksJson, _ := json.Marshal(resp)
	w.Write(booksJson)

	if r.Method == http.MethodPost { // если пост вызываем добавить книгу
		handleAddBook(w, r)

	}

}

func (s BookStore) GetBooks() []Book {
	return s.books

}

func handleGetBook(w http.ResponseWriter, r *http.Request) { //
	id := strings.Replace(r.URL.Path, "/book/", "", 1) // берем id из адреса запроса

	book := bookStore.FindBookById(id) //ищем по базе

	var resp Resp

	if book == nil {
		w.WriteHeader(http.StatusNotFound)

		resp.Error = fmt.Sprintf("")

		respJson, _ := json.Marshal(resp)

		w.Write(respJson)

		return

	}
	resp.Message = book

	respJson, _ := json.Marshal(resp)

	w.WriteHeader(http.StatusOK)

	w.Write(respJson)

}

var bookStore = BookStore{ //задаем массив с нашими книгами
	books: make([]Book, 0),
}

func (s BookStore) FindBookById(id string) *Book { //метод дял поиска книги по ид
	for _, book := range s.books {
		if book.Id == id {
			return &book
		}
	}

	return nil
}

func (s *BookStore) AddBooks(book Book) error {
	for _, bk := range s.books {
		if bk.Id == book.Id {
			return errors.New(fmt.Sprintf("Book with id %s not found", book.Id))
		}

	}
	s.books = append(s.books, book)
	return nil

}

func (s *BookStore) UpdateBook(book Book) error {
	for i, bk := range s.books {
		if bk.Id == book.Id {
			s.books[i] = book
			return nil
		}

	}

	return errors.New(fmt.Sprintf("Book with id %s not found", book.Id))
}

func (s *BookStore) DeleteBook(id string) error {
	for i, bk := range s.books {
		if bk.Id == id {
			s.books = append(s.books[:i], s.books[i+1:]...) //удаляем элемент
			return nil
		}

	}
	return errors.New(fmt.Sprintf("Book with id %s not found", id))
}
